# ==============================================================================
# Verifica se os poligonos dos prédios submetidos sobrepõem prédios cadastrados
# ==============================================================================

from qgis.core import (
    QgsProject,
    QgsLayerTreeLayer,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsSpatialIndex,
    QgsWkbTypes,
    QgsGeometry,
    Qgis
)
from qgis.PyQt.QtCore import QVariant
from qgis.utils import iface
import processing


def obter_camada_do_grupo(nome_grupo, nome_camada):
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup(nome_grupo)
    if not grupo:
        return None

    for child in grupo.children():
        if isinstance(child, QgsLayerTreeLayer):
            layer = child.layer()
            if layer and layer.name().lower() == nome_camada.lower():
                return layer
    return None


def obter_ou_criar_grupo(nome_grupo):
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup(nome_grupo)
    if not grupo:
        grupo = root.addGroup(nome_grupo)
    return grupo


def remover_camadas_com_nome(nome_camada):
    projeto = QgsProject.instance()
    for layer in list(projeto.mapLayers().values()):
        if layer.name().lower() == nome_camada.lower():
            projeto.removeMapLayer(layer.id())


def corrigir_predio_com_sobreposicao_auxiliares():
    camada_predio = obter_camada_do_grupo("submetidos", "predio")
    camada_sobreposicao = obter_camada_do_grupo("resultados", "sobreposicao_auxiliares")

    if not camada_predio:
        return

    if not camada_sobreposicao or camada_sobreposicao.featureCount() == 0:
        return

    remover_camadas_com_nome("predio_corrigido")

    tolerancia = 0.001
    comportamento_snap = 0

    res_snap = processing.run(
        "native:snapgeometries",
        {
            "INPUT": camada_predio,
            "REFERENCE_LAYER": camada_sobreposicao,
            "TOLERANCE": tolerancia,
            "BEHAVIOR": comportamento_snap,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_predio_ajustado = res_snap["OUTPUT"]
    camada_predio_ajustado.setName("predio_ajustado")

    res_diferenca = processing.run(
        "native:difference",
        {
            "INPUT": camada_predio_ajustado,
            "OVERLAY": camada_sobreposicao,
            "INPUT_FIELDS": [],
            "OVERLAY_FIELDS": [],
            "OVERLAY_FIELDS_PREFIX": "",
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_diferenca = res_diferenca["OUTPUT"]
    camada_diferenca.setName("diferenca")

    res_fix = processing.run(
        "native:fixgeometries",
        {
            "INPUT": camada_diferenca,
            "METHOD": 1,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_diferenca_corrigida = res_fix["OUTPUT"]
    camada_diferenca_corrigida.setName("diferenca_corrigida")

    res_single = processing.run(
        "native:multiparttosingleparts",
        {
            "INPUT": camada_diferenca_corrigida,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_predio_corrigido = res_single["OUTPUT"]
    camada_predio_corrigido.setName("predio_corrigido")

    projeto = QgsProject.instance()
    projeto.addMapLayer(camada_predio_corrigido, False)
    grupo_resultados = obter_ou_criar_grupo("resultados")
    grupo_resultados.addLayer(camada_predio_corrigido)


def detectar_sobreposicao_predio_auxiliares_confinantes():
    camada_predio = obter_camada_do_grupo("submetidos", "predio")
    camada_aux = obter_camada_do_grupo("resultados", "auxiliares_confinantes")

    if not camada_predio:
        iface.messageBar().pushInfo(
            "Sobreposições",
            "A camada 'predio' não foi encontrada no grupo 'submetidos'."
        )
        return "0|0"

    if not camada_aux:
        return "0|0"

    if camada_aux.featureCount() == 0:
        return "0|0"

    idx_ncr = camada_aux.fields().indexFromName("nationalcadastralreference")
    if idx_ncr == -1:
        return "0|0"

    feats_predio = [
        (feat.id(), feat.geometry())
        for feat in camada_predio.getFeatures()
        if feat.geometry() and not feat.geometry().isEmpty()
    ]

    feats_aux = []
    for feat in camada_aux.getFeatures():
        geom = feat.geometry()
        if geom and not geom.isEmpty():
            feats_aux.append(
                (feat.id(), geom, feat[idx_ncr])
            )

    if not feats_predio or not feats_aux:
        return "0|0"

    index_aux = QgsSpatialIndex()
    dados_aux = {}

    for fid_aux, geom_aux, ncr in feats_aux:
        feat_temp = QgsFeature()
        feat_temp.setId(fid_aux)
        feat_temp.setGeometry(geom_aux)
        index_aux.insertFeature(feat_temp)
        dados_aux[fid_aux] = {
            "geom": geom_aux,
            "ncr": ncr
        }

    crs_authid = camada_predio.crs().authid()
    camada_saida = QgsVectorLayer(
        f"MultiPolygon?crs={crs_authid}",
        "sobreposicao_auxiliares",
        "memory"
    )

    prov = camada_saida.dataProvider()
    prov.addAttributes([
        QgsField("fid_predio", QVariant.Int),
        QgsField("fid_aux", QVariant.Int),
        QgsField("nationalcadastralreference", QVariant.String)
    ])
    camada_saida.updateFields()

    feats_out = []
    valores_ncr_unicos = set()

    for fid_predio, geom_predio in feats_predio:
        ids_candidatos = index_aux.intersects(geom_predio.boundingBox())

        for fid_aux in ids_candidatos:
            geom_aux = dados_aux[fid_aux]["geom"]
            valor_ncr = dados_aux[fid_aux]["ncr"]
            inter = geom_predio.intersection(geom_aux)

            if not inter or inter.isEmpty():
                continue

            if inter.wkbType() == QgsWkbTypes.GeometryCollection:
                success = inter.convertGeometryCollectionToSubclass(Qgis.GeometryType.Polygon)
                if not success:
                    parts = inter.extractPartsByType(QgsWkbTypes.Polygon)
                    if parts:
                        inter = QgsGeometry.collectGeometry(parts)
                    else:
                        continue

            if inter and not inter.isEmpty() and inter.area() > 0:
                feat_out = QgsFeature(camada_saida.fields())
                feat_out.setGeometry(inter)
                feat_out.setAttributes([
                    fid_predio,
                    fid_aux,
                    None if valor_ncr in [None, ""] else str(valor_ncr)
                ])
                feats_out.append(feat_out)

                if valor_ncr not in [None, ""]:
                    valores_ncr_unicos.add(str(valor_ncr))

    n_sobreposicoes = len(feats_out)
    #n_ncr_unicos = len(valores_ncr_unicos)
    valores_ncr_ordenados = sorted(valores_ncr_unicos)
    ncr_str = ",".join(valores_ncr_ordenados)

    if n_sobreposicoes == 0:
        msg_auxiliares=f"{"0|0"}"
        #return "0|0"
        return msg_auxiliares
    prov.addFeatures(feats_out)
    camada_saida.updateExtents()

    remover_camadas_com_nome("sobreposicao_auxiliares")

    projeto = QgsProject.instance()
    projeto.addMapLayer(camada_saida, False)
    grupo_resultados = obter_ou_criar_grupo("resultados")
    grupo_resultados.addLayer(camada_saida)

    corrigir_predio_com_sobreposicao_auxiliares()
    msg_auxiliares=f"{n_sobreposicoes}|{ncr_str}"
    
    #return f"{n_sobreposicoes}|{ncr_str}"
    return msg_auxiliares

# Executar
#resultado = detectar_sobreposicao_predio_auxiliares_confinantes()
#print(resultado)