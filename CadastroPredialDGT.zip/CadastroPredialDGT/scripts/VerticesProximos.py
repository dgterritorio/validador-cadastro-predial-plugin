# ==========================================================
# Comparação e criação de camada com vértices próximos (≤ tolerância)
# Considera apenas camadas poligonais GPKG no grupo "submetidos" e
# adiciona todas as camadas geradas ao grupo "resultados".
# ==========================================================
# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
    QgsField, QgsFields, QgsWkbTypes, QgsSpatialIndex, QgsVectorFileWriter,
    QgsFeatureRequest
)
from qgis.utils import iface
from qgis.core import Qgis, QgsMessageLog
import tempfile, os
from datetime import datetime
from qgis.PyQt.QtWidgets import QMessageBox

# ==========================================================
# Utilitários
# ==========================================================

def mostrar_mensagem(texto, titulo="Vértices inconsistentes "):
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle(titulo)
    msg_box.setText(texto)
    msg_box.exec_()

def obter_camadas_do_grupo_submetidos():
    """Retorna apenas camadas vetoriais de polígonos GPKG presentes no grupo 'submetidos'."""
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()
    grupo = root.findGroup("submetidos")
    if not grupo:
        iface.messageBar().pushWarning("Aviso", "Grupo 'submetidos' não encontrado no projeto.")
        return []
    camadas = []
    for child in grupo.children():
        if hasattr(child, "layer") and child.layer() is not None:
            lyr = child.layer()
            try:
                if (
                    isinstance(lyr, QgsVectorLayer)
                    and lyr.isValid()
                    and lyr.providerType() == "ogr"
                    and "gpkg" in lyr.source().lower()
                    and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry
                ):
                    camadas.append(lyr)
            except Exception:
                # ignorar camadas que causem erro de introspecção
                continue
    return camadas

def adicionar_layer_ao_grupo(layer, nome_grupo="resultados"):
    """Adiciona a camada ao projeto dentro do grupo nome_grupo (cria o grupo se não existir)."""
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()
    grupo = root.findGroup(nome_grupo)
    if not grupo:
        grupo = root.addGroup(nome_grupo)
    # adiciona ao projeto sem inserir na raiz
    projeto.addMapLayer(layer, False)
    # insere na posição 0 do grupo (aparece no topo do grupo)
    grupo.insertLayer(0, layer)

# ==========================================================
# Principal
# ==========================================================

def vertices_proximos_main(tolerancia_prox):
    """
    Executa a análise de vértices próximos (<= tolerancia_prox metros).
    Considera apenas camadas GPKG de polígonos em 'submetidos'.
    Cria camadas/GeoPackages temporários e adiciona-os ao grupo 'resultados'.
    """
    project = QgsProject.instance()
    tmpdir = tempfile.mkdtemp(prefix="qgis_tmp_")
    QgsMessageLog.logMessage(f"Pasta temporária usada: {tmpdir}", "validador_cns", Qgis.Info)

    tolerancia = float(tolerancia_prox)

    def get_xy(pt):
        # garante compatibilidade com vários tipos de pontos
        if hasattr(pt, "x") and hasattr(pt, "y"):
            return float(pt.x()), float(pt.y())
        elif isinstance(pt, (tuple, list)) and len(pt) >= 2:
            return float(pt[0]), float(pt[1])
        else:
            raise TypeError(f"Tipo de ponto não suportado: {type(pt)}")

    # === Obter camadas poligonais do grupo 'submetidos' ===
    layers = obter_camadas_do_grupo_submetidos()
    if not layers:
        mostrar_mensagem("Nenhuma camada de polígonos GPKG encontrada no grupo 'submetidos'.")
        return

    crs = layers[0].crs()

    # === Extrair segmentos de todas as camadas ===
    lines_fields = QgsFields()
    lines_fields.append(QgsField("poly_id", QVariant.String))
    lines_fields.append(QgsField("seg_id", QVariant.Int))

    all_lines_features = []
    for lyr in layers:
        lname = lyr.name()
        seg_counter = 0
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            poly_id = f"{lname}_{feat.id()}"
            polygons = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
            for poly in polygons:
                for ring in poly:
                    # remover vértice final repetido (se existir)
                    ring_pts = list(ring)
                    if len(ring_pts) > 1 and ring_pts[0] == ring_pts[-1]:
                        ring_pts = ring_pts[:-1]
                    for i in range(len(ring_pts) - 1):
                        p1 = QgsPointXY(*get_xy(ring_pts[i]))
                        p2 = QgsPointXY(*get_xy(ring_pts[i + 1]))
                        seg_geom = QgsGeometry.fromPolylineXY([p1, p2])
                        fseg = QgsFeature()
                        fseg.setGeometry(seg_geom)
                        fseg.setFields(lines_fields)
                        fseg["poly_id"] = poly_id
                        fseg["seg_id"] = seg_counter
                        seg_counter += 1
                        all_lines_features.append(fseg)

    linhas_gpkg = os.path.join(tmpdir, "linhas.gpkg")
    if all_lines_features:
        mem_lines = QgsVectorLayer(f"LineString?crs={crs.authid()}", "linhas", "memory")
        prov = mem_lines.dataProvider()
        prov.addAttributes(lines_fields)
        mem_lines.updateFields()
        prov.addFeatures(all_lines_features)
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = "linhas"
        QgsVectorFileWriter.writeAsVectorFormatV2(mem_lines, linhas_gpkg, project.transformContext(), opts)
        linhas_layer = QgsVectorLayer(f"{linhas_gpkg}|layername=linhas", "linhas", "ogr")
        # adicionar ao grupo resultados
        adicionar_layer_ao_grupo(linhas_layer, "resultados")
    else:
        linhas_layer = None
        QgsMessageLog.logMessage("Nenhum segmento gerado.", "validador_cns", Qgis.Warning)

    # === Extrair vértices únicos ===
    vert_fields = QgsFields()
    vert_fields.append(QgsField("poly_id", QVariant.String))
    vert_fields.append(QgsField("vert_id", QVariant.Int))

    vertices = []
    seen = set()
    vcount = 0
    for lyr in layers:
        lname = lyr.name()
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            poly_id = f"{lname}_{feat.id()}"
            polygons = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
            for poly in polygons:
                for ring in poly:
                    ring_pts = list(ring)
                    if len(ring_pts) > 1 and ring_pts[0] == ring_pts[-1]:
                        ring_pts = ring_pts[:-1]
                    for pt in ring_pts:
                        x, y = get_xy(pt)
                        key = (round(x, 9), round(y, 9), poly_id)
                        if key in seen:
                            continue
                        seen.add(key)
                        fv = QgsFeature()
                        fv.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                        fv.setFields(vert_fields)
                        fv["poly_id"] = poly_id
                        fv["vert_id"] = vcount
                        vcount += 1
                        vertices.append(fv)

    verts_gpkg = os.path.join(tmpdir, "vertices_unicos.gpkg")
    if vertices:
        mem_verts = QgsVectorLayer(f"Point?crs={crs.authid()}", "vertices_unicos", "memory")
        prov = mem_verts.dataProvider()
        prov.addAttributes(vert_fields)
        mem_verts.updateFields()
        prov.addFeatures(vertices)
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = "vertices_unicos"
        QgsVectorFileWriter.writeAsVectorFormatV2(mem_verts, verts_gpkg, project.transformContext(), opts)
        verts_layer = QgsVectorLayer(f"{verts_gpkg}|layername=vertices_unicos", "vertices_unicos", "ogr")
        adicionar_layer_ao_grupo(verts_layer, "resultados")
    else:
        verts_layer = None
        QgsMessageLog.logMessage("Nenhum vértice único gerado.", "validador_cns", Qgis.Warning)

    # === Índice espacial e cálculo de distâncias entre vértice e segmentos ===
    index = QgsSpatialIndex()
    lines_geoms = {}
    if linhas_layer and linhas_layer.isValid():
        for f in linhas_layer.getFeatures():
            # inserir na árvore espacial; garantir id único para index
            temp_f = QgsFeature()
            temp_f.setGeometry(f.geometry())
            temp_f.setId(f.id())
            index.insertFeature(temp_f)
            lines_geoms[f.id()] = f.geometry()

    res_fields = QgsFields()
    res_fields.append(QgsField("poly_id", QVariant.String))
    res_fields.append(QgsField("vert_id", QVariant.Int))
    res_fields.append(QgsField("dist", QVariant.Double))

    res_feats = []
    count_close = 0
    for v in vertices:
        geom = v.geometry()
        min_dist = None
        if lines_geoms:
            # obter nearest candidates
            try:
                nearest_ids = index.nearestNeighbor(geom.asPoint(), 50)
            except Exception:
                nearest_ids = []
            for nid in nearest_ids:
                lg = lines_geoms.get(nid)
                if not lg:
                    continue
                d = geom.distance(lg)
                if d == 0:
                    continue
                if min_dist is None or d < min_dist:
                    min_dist = d
        dist_val = min_dist if min_dist is not None else -1.0

        if 0 < dist_val <= tolerancia:
            count_close += 1

        nf = QgsFeature()
        nf.setGeometry(geom)
        nf.setFields(res_fields)
        nf["poly_id"] = v["poly_id"]
        nf["vert_id"] = v["vert_id"]
        nf["dist"] = dist_val
        res_feats.append(nf)

    # === Criar camada Resultado (todas as distâncias calculadas) ===
    resultado_gpkg = os.path.join(tmpdir, "Resultado.gpkg")
    mem_res = QgsVectorLayer(f"Point?crs={crs.authid()}", "Resultado", "memory")
    prov = mem_res.dataProvider()
    prov.addAttributes(res_fields)
    mem_res.updateFields()
    if res_feats:
        prov.addFeatures(res_feats)
    mem_res.updateExtents()
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GPKG"
    opts.layerName = "Resultado"
    QgsVectorFileWriter.writeAsVectorFormatV2(mem_res, resultado_gpkg, project.transformContext(), opts)
    resultado_layer = QgsVectorLayer(f"{resultado_gpkg}|layername=Resultado", "Resultado", "ogr")
    adicionar_layer_ao_grupo(resultado_layer, "resultados")

    # === Criar GeoPackage com vértices dentro da tolerância ===
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    prox_gpkg = os.path.join(tmpdir, f"vertices_proximos_{ts}.gpkg")
    layer_name = "Vertices_inconsistentes"
    prox_feats = [f for f in res_feats if 0 < f["dist"] <= tolerancia]
    if prox_feats:
        mem_prox = QgsVectorLayer(f"Point?crs={crs.authid()}", layer_name, "memory")
        prov = mem_prox.dataProvider()
        prov.addAttributes(res_fields)
        mem_prox.updateFields()
        prov.addFeatures(prox_feats)
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = layer_name
        #QgsVectorFileWriter.writeAsVectorFormatV2(mem_prox, prox_gpkg, project.transformContext(), opts)
        #vlayer = QgsVectorLayer(f"{prox_gpkg}|layername={layer_name}", layer_name, "ogr")
        #adicionar_layer_ao_grupo(vlayer, "resultados")
        #adicionar ao projeto o ficheiro temporário
        adicionar_layer_ao_grupo(mem_prox, "resultados")
    else:
        prox_gpkg = None

    # Mensagem final
    if count_close:
        
        msg=(f"{count_close}")
    else:
        
        msg=(f"{count_close}")

    return msg
    
    QgsMessageLog.logMessage(f"Processo concluído. Temp dir: {tmpdir}", "CadastroPredialDGT", Qgis.Info)

# === Exemplo de chamada: definir tolerância em metros (ex: 0.001 = 1 mm)
# Executar
#vertices_proximos_main(0.001)
