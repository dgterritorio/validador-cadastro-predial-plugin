# ==========================================================
# Remover camadas em memória no projeto QGIS
# ==========================================================
from qgis.core import QgsProject

def remove_memoria():
    
    project = QgsProject.instance()
    root = project.layerTreeRoot()

    # IDs das camadas que estão na TOC
    layer_tree_ids = {node.layerId() for node in root.findLayers()}

#    Percorrer todas as camadas do projeto QGIS
    for layer_id, layer in list(project.mapLayers().items()):
    
        # Verificar se é camada temporária (memory)
        if layer.providerType() == "memory":
        
            # Verificar se NÃO está na TOC
            if layer_id not in layer_tree_ids:
                print(f"Removendo camada temporária fora da TOC: {layer.name()}")
                project.removeMapLayer(layer_id)

    print("Camadas em memória removidas.")
# Executar
#remove_memoria()