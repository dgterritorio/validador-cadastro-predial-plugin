# ==============================================================================
# Verifica se os poligonos submetidos nos temas dominio_publico e area_nao_cadastrada ultrapassam
# os limites exteriores do(s) prédio(s) originai(s)
# Tolerância de 1 mm para o ajuste do predio original ao dominio_publico e/ou do predio original à area_nao_cadastrada
# ==============================================================================
# -*- coding: utf-8 -*-
from qgis.core import (
    QgsProject,
    QgsGeometry,
    QgsFeatureRequest
)
from qgis.PyQt.QtWidgets import QMessageBox
import processing

TOLERANCIA = 0.001  # 1 mm


def mostrar_mensagem(texto):
    """Exibe uma caixa de diálogo com a mensagem."""
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Ultrapassa limite exterior prédio original")
    msg_box.setText(texto)
    msg_box.exec_()
    
    
def get_group(nome):
    root = QgsProject.instance().layerTreeRoot()
    return root.findGroup(nome)


def get_layer_from_group(group_name, layer_name):
    grupo = get_group(group_name)
    if grupo is None:
        return None

    wanted = layer_name.strip().lower()
    for child in grupo.children():
        if hasattr(child, "layer"):
            lyr = child.layer()
            if lyr and lyr.name().strip().lower() == wanted:
                return lyr
    return None


def remove_layer_from_group_by_name(group_name, layer_name):
    grupo = get_group(group_name)
    if not grupo:
        return

    project = QgsProject.instance()
    wanted = layer_name.strip().lower()

    for child in list(grupo.children()):
        if hasattr(child, "layer"):
            lyr = child.layer()
            if lyr and lyr.name().strip().lower() == wanted:
                project.removeMapLayer(lyr.id())


def add_layer_to_group(layer, group_name):
    grupo = get_group(group_name)
    if grupo is None:
        return
    QgsProject.instance().addMapLayer(layer, False)
    grupo.addLayer(layer)


def unir_geometrias_validas(layer):
    geoms = []
    for feat in layer.getFeatures():
        geom = feat.geometry()
        if geom and not geom.isEmpty():
            geoms.append(geom)

    if not geoms:
        return None

    geom_unida = QgsGeometry.unaryUnion(geoms)
    if geom_unida and not geom_unida.isEmpty():
        return geom_unida
    return None


def ajustar_predio_a_camada_validacao(layer_predio, layer_validacao):
    result = processing.run("native:snapgeometries", {
        "INPUT": layer_predio,
        "REFERENCE_LAYER": layer_validacao,
        "TOLERANCE": TOLERANCIA,
        "BEHAVIOR": 0,  # Prefer aligning nodes, insert extra vertices where required
        "OUTPUT": "TEMPORARY_OUTPUT"
    })

    camada_ajustada = result["OUTPUT"]
    camada_ajustada.setName("predio_original_ajustada")
    return camada_ajustada


def criar_camada_erros(layer_origem, feature_ids_erro, nome_camada):
    if not feature_ids_erro:
        return None

    camada_erros = layer_origem.materialize(
        QgsFeatureRequest().setFilterFids(feature_ids_erro)
    )
    camada_erros.setName(nome_camada)
    return camada_erros


def obter_texto_camada(camada_validar_nome):
    textos = {
        "dominio_publico": "domínio público",
        "area_nao_cadastrada": "área não cadastrada"
    }
    return textos.get(camada_validar_nome, camada_validar_nome.replace("_", " "))


def obter_mensagem_validacao(camada_validar_nome, numero_erros):
    texto_camada = obter_texto_camada(camada_validar_nome)
    return (
        f"Existem {numero_erros} polígonos de {texto_camada} "
        f"que ultrapassam o prédio original."
    )


def criar_diferenca_se_erro_existir(nome_camada_erro, nome_saida):
    layer_erro = get_layer_from_group("resultados", nome_camada_erro)
    layer_predio_ajustado = get_layer_from_group("resultados", "predio_original_ajustada")

    if layer_erro is None or layer_predio_ajustado is None:
        return None

    if layer_erro.featureCount() == 0:
        return None

    remove_layer_from_group_by_name("resultados", nome_saida)

    result = processing.run("native:difference", {
        "INPUT": layer_erro,
        "OVERLAY": layer_predio_ajustado,
        "OUTPUT": "TEMPORARY_OUTPUT"
    })

    camada_diferenca = result["OUTPUT"]
    camada_diferenca.setName(nome_saida)
    add_layer_to_group(camada_diferenca, "resultados")
    return camada_diferenca


def criar_camadas_diferenca_erros():
    criar_diferenca_se_erro_existir(
        "area_nao_cadastrada_erro",
        "area_a_mais_de_areanaocadastrada"
    )

    criar_diferenca_se_erro_existir(
        "dominio_publico_erro",
        "area_a_mais_de_dominiopublico"
    )




    


def validar_ultrapassagem_limite(camada_validar_nome):
    layer_predio = get_layer_from_group("originais", "predio")
    layer_validacao = get_layer_from_group("submetidos", camada_validar_nome)

    if layer_predio is None or layer_validacao is None:
        return

#    if layer_validacao.featureCount() == 0:
#        QMessageBox.information(
#            None,
#            "Informação",
#            obter_mensagem_validacao(camada_validar_nome, 0)
#        )
#        return

    remove_layer_from_group_by_name("resultados", "predio_original_ajustada")
    remove_layer_from_group_by_name("resultados", f"{camada_validar_nome}_erro")

    layer_predio_ajustada = ajustar_predio_a_camada_validacao(layer_predio, layer_validacao)
    add_layer_to_group(layer_predio_ajustada, "resultados")

    geom_predio = unir_geometrias_validas(layer_predio_ajustada)
    if geom_predio is None:
        QMessageBox.information(
            None,
            "Informação",
            obter_mensagem_validacao(camada_validar_nome, 0)
        )
        return

    erros_ids = []

    for feat in layer_validacao.getFeatures():
        geom_val = feat.geometry()
        if geom_val is None or geom_val.isEmpty():
            continue

        if not geom_predio.contains(geom_val):
            erros_ids.append(feat.id())

    numero_erros = len(erros_ids)
    
    

#Se existirem erros
    if numero_erros > 0:
    
        nome_camada_erro = f"{camada_validar_nome}_erro"
        camada_erros = criar_camada_erros(layer_validacao, erros_ids, nome_camada_erro)
        
        
        if camada_erros is not None:
            add_layer_to_group(camada_erros, "resultados")
        criar_camadas_diferenca_erros()
        #QMessageBox.warning(None,"Aviso",obter_mensagem_validacao(camada_validar_nome, numero_erros))
        
        
        return numero_erros
    else:
        numero_erros=(f"0")
        #QMessageBox.information(None,"Informação",obter_mensagem_validacao(camada_validar_nome, 0))
    return numero_erros
    
#validar_ultrapassagem_limite("dominio_publico")
#validar_ultrapassagem_limite("area_nao_cadastrada")
#remove_layer_from_group_by_name("resultados", "predio_original_ajustada")
#remove_layer_from_group_by_name("resultados", "dominio_publico_erro")
#remove_layer_from_group_by_name("resultados", "area_nao_cadastrada_erro")
