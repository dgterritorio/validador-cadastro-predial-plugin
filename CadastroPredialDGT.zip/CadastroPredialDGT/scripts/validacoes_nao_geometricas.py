#from qgis.core import QgsProject, QgsLayerTreeLayer
#from qgis.PyQt.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QMessageBox
from qgis.utils import iface
from qgis.core import Qgis, QgsMessageLog
import os
#from qgis.PyQt.QtGui import QIcon

ICON_PATH = os.path.join(os.path.dirname(__file__), "icon.png")

from qgis.core import (
    QgsProject, QgsGeometry, QgsPointXY, QgsVectorLayer,
    QgsVectorFileWriter, QgsFields, QgsField,QgsLayerTreeLayer, QgsFeature, QgsWkbTypes
)
from PyQt5.QtCore import QVariant




def mostrar_mensagem(texto):
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    #msg_box.setWindowIcon(QIcon(ICON_PATH))
    msg_box.setWindowTitle("Validações não geométricas")
    msg_box.setText(texto)
    msg_box.exec_()
    
def obter_camadas_grupo(nome_grupo):
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup(nome_grupo)

    if not grupo:
        return None

    camadas = []
    for child in grupo.children():
        if isinstance(child, QgsLayerTreeLayer):
            lyr = child.layer()
            if lyr and lyr.isValid():
                # ignorar tabelas sem geometria
                if not lyr.isSpatial():
                    continue
                camadas.append(lyr)

    return camadas


def contar_registos(layer):
    return sum(1 for _ in layer.getFeatures())


def geometrias_iguais_topologicamente(lyr_a, lyr_b):
    feats_a = list(lyr_a.getFeatures())
    feats_b = list(lyr_b.getFeatures())

    if len(feats_a) != len(feats_b):
        return False

    usados_b = set()

    for fa in feats_a:
        ga = fa.geometry()

        if ga is None or ga.isNull() or ga.isEmpty():
            return False

        encontrou = False

        for idx_b, fb in enumerate(feats_b):
            if idx_b in usados_b:
                continue

            gb = fb.geometry()

            if gb is None or gb.isNull() or gb.isEmpty():
                continue

            if ga.isGeosEqual(gb):
                usados_b.add(idx_b)
                encontrou = True
                break

        if not encontrou:
            return False

    return True


def camada_igual_a_homologa(lyr_subm, lyr_orig):
    n_subm = contar_registos(lyr_subm)
    n_orig = contar_registos(lyr_orig)

    # Ambas vazias -> iguais
    if n_subm == 0 and n_orig == 0:
        return True

    # Nº de registos diferente -> diferentes
    if n_subm != n_orig:
        return False

    # Mesmo nº de registos -> comparar geometrias
    return geometrias_iguais_topologicamente(lyr_subm, lyr_orig)


def verificar_grupo_submetidos():
    nome_grupo = "submetidos"
    nome_grupo_orig = "originais"

    camadas_obrigatorias = {
        "predio",
        "confinantes",
        "dominio_publico",
        "area_nao_cadastrada",
        "dominio_publico_confinante",
        "adicionais",
    }

    erros = []
    continuar = "sim"

    camadas = obter_camadas_grupo(nome_grupo)

    if camadas is None:
        erros.append(f"O grupo '{nome_grupo}' não existe no projeto.")
        continuar = "nao"

    elif not camadas:
        erros.append(f"O grupo '{nome_grupo}' não contém camadas.")
        continuar = "nao"

    else:
        nomes_camadas = {lyr.name().strip() for lyr in camadas}

        # 1. Número de camadas
        if len(camadas) != 6:
            erros.append(
                f"O grupo '{nome_grupo}' contém {len(camadas)} camadas e deve conter exatamente 6."
            )
            continuar = "nao"

        # 2. Camadas em falta
        em_falta = sorted(camadas_obrigatorias - nomes_camadas)
        if em_falta:
            erros.append(
                f"Faltam as camadas obrigatórias: {', '.join(em_falta)}."
            )
            continuar = "nao"

        # 3. Camadas a mais
        a_mais = sorted(nomes_camadas - camadas_obrigatorias)
        if a_mais:
            erros.append(
                f"Existem camadas não permitidas: {', '.join(a_mais)}."
            )
            continuar = "nao"

        dict_subm = {lyr.name().strip(): lyr for lyr in camadas}

        # 4. Validação individual das camadas submetidos
        for lyr in camadas:
            nome = lyr.name().strip()

            if not lyr.isValid():
                erros.append(f"A camada '{nome}' não é válida.")
                continuar = "nao"
                continue

            authid = lyr.crs().authid()
            if authid != "EPSG:3763":
                erros.append(
                    f"A camada '{nome}' está em {authid} e não em EPSG:3763."
                )
                continuar = "nao"

            total_registos = 0
            total_com_geometria = 0
            total_sem_geometria = 0

            for feat in lyr.getFeatures():
                total_registos += 1
                geom = feat.geometry()

                if geom is None or geom.isNull() or geom.isEmpty():
                    total_sem_geometria += 1
                else:
                    total_com_geometria += 1

            if total_registos != total_com_geometria:
                erros.append(
                    f"A camada '{nome}' tem {total_registos} registos, "
                    f"mas apenas {total_com_geometria} com geometria; "
                    f"{total_sem_geometria} registos não têm geometria."
                )
                continuar = "nao"

        # 5. Validação específica: nº de polígonos da camada confinantes
        camadas_orig = obter_camadas_grupo(nome_grupo_orig)

        if camadas_orig is None:
            erros.append(f"O grupo '{nome_grupo_orig}' não existe no projeto.")
            continuar = "nao"

        elif not camadas_orig:
            erros.append(f"O grupo '{nome_grupo_orig}' não contém camadas.")
            continuar = "nao"

        else:
            dict_orig = {lyr.name().strip(): lyr for lyr in camadas_orig}

            lyr_conf_subm = dict_subm.get("confinantes")
            lyr_conf_orig = dict_orig.get("confinantes")

            if lyr_conf_subm and lyr_conf_orig:
                n_conf_subm = contar_registos(lyr_conf_subm)
                n_conf_orig = contar_registos(lyr_conf_orig)

                if n_conf_subm != n_conf_orig:
                    erros.append(
                        f"A camada 'confinantes' do grupo '{nome_grupo}' tem "
                        f"{n_conf_subm} polígonos e a camada 'confinantes do grupo '{nome_grupo_orig}' "
                        f"tem {n_conf_orig} polígonos. Os confinantes submetidos tem que apresentar o mesmo número de polígonos em relação aos originais."
                    )
                    continuar = "nao"

            # 6. Comparação global com 'originais':
            # só dá erro se TODAS as 6 camadas obrigatórias forem iguais
            todas_iguais = True

            for nome in sorted(camadas_obrigatorias):
                lyr_subm = dict_subm.get(nome)
                lyr_orig = dict_orig.get(nome)

                if lyr_subm is None or lyr_orig is None:
                    todas_iguais = False
                    break

                if not camada_igual_a_homologa(lyr_subm, lyr_orig):
                    todas_iguais = False
                    break

            if todas_iguais:
                erros.append("Os dados submetidos são iguais aos dados originais.")
                continuar = "nao"

    # Mensagem final única
    if erros:
        mensagem_ng = "\n\n".join(erros)
        
        
        #mostrar_mensagem(mensagem)
        iface.messageBar().pushMessage("Validação gpkg", "Fim de validação...", level=Qgis.Info, duration=0)
        print(mensagem_ng)
        
        #return
    else:
        mensagem_ng = (
            "Validação concluída com sucesso: o grupo 'submetidos' contém exatamente "
            "as 6 camadas obrigatórias, todas válidas, em EPSG:3763 e sem registos sem geometria."
        )
        print(mensagem_ng)

    return continuar,mensagem_ng

#Executar
#verificar_grupo_submetidos()
