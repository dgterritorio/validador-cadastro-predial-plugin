# ==========================================================
# deteta lacunas nas camadas geopackage existentes no grupo "submetidos"
# correção:ignora a camada "adicionais" se existir nos grupos "originais" e "submetidos"
# adiciona o ficheiro de erros apenas se existirem registos
# ==========================================================

from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsMessageLog
)
import processing

from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.utils import iface


def obter_grupo_resultados():
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()
    grupo = root.findGroup("resultados")
    if not grupo:
        grupo = root.addGroup("resultados")
    return grupo


def mostrar_mensagem(texto):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setWindowTitle("Lacunas")
    msg.setText(texto)
    msg.exec_()


def juntar_e_dissolver(nome_grupo_origem, nome_saida, grupo_resultados):
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()
    grupo_origem = root.findGroup(nome_grupo_origem)

    if not grupo_origem:
        QgsMessageLog.logMessage(f"Grupo {nome_grupo_origem} não encontrado.", "Validação")
        return None

    camadas = []
    for child in grupo_origem.findLayers():
        layer = child.layer()
        if not layer:
            continue
        #ignora a camada adicionais
        if layer.name().strip().lower() == "adicionais":
            continue

        camadas.append(layer)

    if not camadas:
        QgsMessageLog.logMessage(
            f"Sem camadas válidas no grupo {nome_grupo_origem} após excluir 'adicionais'.",
            "Validação"
        )
        return None

    resultado_merge = processing.run("native:mergevectorlayers", {
        'LAYERS': camadas,
        'CRS': camadas[0].crs(),
        'OUTPUT': 'memory:'
    })['OUTPUT']

    resultado_dissolve = processing.run("native:dissolve", {
        'INPUT': resultado_merge,
        'OUTPUT': 'memory:'
    })['OUTPUT']

    camada_final = resultado_dissolve
    camada_final.setName(nome_saida)
    QgsProject.instance().addMapLayer(camada_final, False)
    grupo_resultados.addLayer(camada_final)

    return camada_final


def executar_validacao_lacunas():
    grupo_resultados = obter_grupo_resultados()

    camada_originais = juntar_e_dissolver("originais", "dados_originais1", grupo_resultados)
    if not camada_originais:
        return

    camada_submetidos = juntar_e_dissolver("submetidos", "dados_submetidos1", grupo_resultados)
    if not camada_submetidos:
        return

    resultado_diff = processing.run("native:difference", {
        'INPUT': camada_originais,
        'OVERLAY': camada_submetidos,
        'OUTPUT': 'memory:'
    })['OUTPUT']

    resultado_explode = processing.run("native:multiparttosingleparts", {
        'INPUT': resultado_diff,
        'OUTPUT': 'memory:'
    })['OUTPUT']

    camada_lacunas_C = QgsVectorLayer(
        'memory:?geometry=Polygon&crs=' + resultado_explode.crs().authid(),
        'lacunas',
        'memory'
    )
    camada_lacunas_C.dataProvider().addFeatures([f for f in resultado_explode.getFeatures()])
    QgsProject.instance().addMapLayer(camada_lacunas_C, False)
    # grupo_resultados.addLayer(camada_lacunas_C)

    expr = "(4 * pi() * $area) / ($perimeter * $perimeter) > 0.0001"

    resultado_filtrado = processing.run("native:extractbyexpression", {
        'INPUT': resultado_explode,
        'EXPRESSION': expr,
        'OUTPUT': 'memory:'
    })['OUTPUT']

    camada_lacunas = QgsVectorLayer(
        'memory:?geometry=Polygon&crs=' + resultado_filtrado.crs().authid(),
        'lacunas',
        'memory'
    )
    camada_lacunas.dataProvider().addFeatures([f for f in resultado_filtrado.getFeatures()])

    n = camada_lacunas.featureCount()

    if n > 0:
        QgsProject.instance().addMapLayer(camada_lacunas, False)
        grupo_resultados.addLayer(camada_lacunas)
        msg1 = f"{n}"
    else:
        msg1 = f"{n}"

    return msg1


# Executar
# executar_validacao_lacunas()