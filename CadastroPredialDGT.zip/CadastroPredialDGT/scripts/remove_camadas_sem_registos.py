# ==========================================================
# Remover camadas temporárias sem registos do projeto QGIS
# ==========================================================
# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
    QgsField, QgsFields, QgsWkbTypes, QgsSpatialIndex, QgsVectorFileWriter
)
from qgis.utils import iface
from qgis.core import Qgis, QgsMessageLog
import tempfile, os
from datetime import datetime
from qgis.PyQt.QtWidgets import QMessageBox

def mostrar_mensagem(texto):
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Resultado Vértices inconsistentes ")
    msg_box.setText(texto)
    msg_box.exec_()

def contar_registos_seguro(layer):
    if layer is None or not isinstance(layer, QgsVectorLayer):
        return None

    total = layer.featureCount()

    if total is not None and total >= 0:
        return total

    count = 0
    for _ in layer.getFeatures():
        count += 1
    return count


def remove_camadas_vazias_do_grupo_resultados():
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()
    grupo = root.findGroup("resultados")

    if grupo is None:
        return

    layers_para_remover = []

    for child in grupo.children():
        if hasattr(child, "layer"):
            lyr = child.layer()
            if lyr and isinstance(lyr, QgsVectorLayer):
                nr_registos = contar_registos_seguro(lyr)
                if nr_registos == 0:
                    layers_para_remover.append(lyr.id())

    for layer_id in layers_para_remover:
        projeto.removeMapLayer(layer_id)

# Executar
# remove_camadas_vazias_do_grupo_resultados()