# ==========================================================
# Remover grupo do projeto QGIS
# ==========================================================
from qgis.core import QgsProject, QgsLayerTreeGroup, QgsLayerTreeLayer

def remover_grupo(nome_grupo):
    project = QgsProject.instance()
    root = project.layerTreeRoot()

    grupo = root.findGroup(nome_grupo)
    if not grupo:
        print(f"Grupo '{nome_grupo}' não encontrado.")
        return

    # Remover as camadas do projeto
    for child in list(grupo.children()):
        if isinstance(child, QgsLayerTreeLayer):
            layer = child.layer()
            if layer:
                project.removeMapLayer(layer.id())

    # Remover o próprio grupo
    root.removeChildNode(grupo)

    print(f"Grupo '{nome_grupo}' e respetivas camadas removidos.")
# Executar
#remover_grupo("corrigidos")
# ou
#remover_grupo("originais")