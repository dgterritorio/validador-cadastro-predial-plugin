# ==========================================================
# Faz Zoom à camada predio do grupo originais
# ==========================================================
from qgis.core import QgsProject, Qgis
from qgis.utils import iface

def zoom_camada_grupo(nome_camada="predio", nome_grupo="originais"):
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()

    grupo = root.findGroup(nome_grupo)
    if not grupo:
        msg = f"Grupo '{nome_grupo}' não encontrado."
        iface.messageBar().pushMessage("Erro", msg, level=Qgis.Critical, duration=5)
        raise Exception(msg)

    camada = None
    for node in grupo.findLayers():
        if node.layer().name() == nome_camada:
            camada = node.layer()
            break

    if not camada:
        # Listar camadas existentes para ajudar no debug
        nomes_existentes = [node.layer().name() for node in grupo.findLayers()]
        msg = (f"Camada '{nome_camada}' não encontrada no grupo '{nome_grupo}'.\n"
               f"Camadas existentes: {nomes_existentes}")
        
        iface.messageBar().pushMessage("Erro", msg, level=Qgis.Critical, duration=7)
        raise Exception(msg)

    canvas = iface.mapCanvas()
    canvas.setScaleLocked(False)
    
    iface.setActiveLayer(camada)
    iface.mapCanvas().setExtent(camada.extent())
    iface.zoomToActiveLayer()
    iface.mapCanvas().refresh()
    
    return camada
# Executa
#zoom_camada_grupo()