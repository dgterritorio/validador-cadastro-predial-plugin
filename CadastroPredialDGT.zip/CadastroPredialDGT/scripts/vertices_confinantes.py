# ==========================================================
# Verifica se existem alterações nos confinantes em estremas não comuns ao prédio a conservar
# ==========================================================
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsField,
    QgsFields,
    QgsVectorFileWriter,
    QgsWkbTypes,
)
import tempfile
import os

tmpdir = tempfile.mkdtemp(prefix="qgis_tmp_")

# ==========================================================
# Utilitários
# ==========================================================

def get_xy(pt):
    if hasattr(pt, "x") and hasattr(pt, "y"):
        return float(pt.x()), float(pt.y())
    raise TypeError(f"Tipo de ponto não suportado: {type(pt)}")


def norm_xy(x, y, ndigits=9):
    return (round(float(x), ndigits), round(float(y), ndigits))


def mostrar_mensagem(texto):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setWindowTitle("Confinantes")
    msg.setText(texto)
    msg.exec_()


def obter_grupo(nome_grupo):
    root = QgsProject.instance().layerTreeRoot()
    return root.findGroup(nome_grupo)


def obter_camadas_do_grupo(nome_grupo):
    grupo = obter_grupo(nome_grupo)

    if not grupo:
        print(f"⚠️ Grupo '{nome_grupo}' não existe.")
        return []

    camadas = []
    for node in grupo.children():
        if hasattr(node, "layer"):
            lyr = node.layer()
            if lyr and lyr.isValid() and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry:
                camadas.append(lyr)

    print(f"Encontradas {len(camadas)} camadas no grupo '{nome_grupo}'.")
    return camadas


def obter_ou_criar_grupo_resultados():
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup("resultados")
    if not grupo:
        grupo = root.addGroup("resultados")
    return grupo


def obter_camadas_predio(camadas):
    return [lyr for lyr in camadas if "predio" in lyr.name().lower()]


def obter_camadas_confinantes(camadas):
    return [lyr for lyr in camadas if "confinante" in lyr.name().lower()]


def geometria_valida(geom):
    if not geom or geom.isEmpty():
        return None

    try:
        if not geom.isGeosValid():
            geom = geom.makeValid()
    except Exception:
        pass

    if not geom or geom.isEmpty():
        return None

    return geom

# ==========================================================
# Obter vértices
# ==========================================================

def extrair_vertices_camada(lyr):
    vertices = set()
    for feat in lyr.getFeatures():
        geom = feat.geometry()
        geom = geometria_valida(geom)
        if not geom:
            continue

        polys = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]
        for poly in polys:
            for ring in poly:
                for pt in ring:
                    x, y = get_xy(pt)
                    vertices.add(norm_xy(x, y))
    return vertices


def extrair_vertices_criticos(camadas):
    confinantes = obter_camadas_confinantes(camadas)
    outras = [lyr for lyr in camadas if lyr not in confinantes]

    vertices_confinantes = set()
    vertices_outras = set()

    for lyr in confinantes:
        vertices_confinantes |= extrair_vertices_camada(lyr)

    for lyr in outras:
        vertices_outras |= extrair_vertices_camada(lyr)

    return vertices_confinantes - vertices_outras


def extrair_vertices_geometria(geom):
    vertices = set()
    if not geom or geom.isEmpty():
        return vertices

    try:
        for part in geom.constParts():
            subgeom = QgsGeometry(part.clone())
            if not subgeom or subgeom.isEmpty():
                continue

            flat = QgsWkbTypes.flatType(subgeom.wkbType())
            gtype = QgsWkbTypes.geometryType(flat)

            if gtype == QgsWkbTypes.PointGeometry:
                if subgeom.isMultipart():
                    for pt in subgeom.asMultiPoint():
                        x, y = get_xy(pt)
                        vertices.add(norm_xy(x, y))
                else:
                    pt = subgeom.asPoint()
                    x, y = get_xy(pt)
                    vertices.add(norm_xy(x, y))

            elif gtype == QgsWkbTypes.LineGeometry:
                linhas = subgeom.asMultiPolyline() if subgeom.isMultipart() else [subgeom.asPolyline()]
                for linha in linhas:
                    for pt in linha:
                        x, y = get_xy(pt)
                        vertices.add(norm_xy(x, y))

            elif gtype == QgsWkbTypes.PolygonGeometry:
                polys = subgeom.asMultiPolygon() if subgeom.isMultipart() else [subgeom.asPolygon()]
                for poly in polys:
                    for ring in poly:
                        for pt in ring:
                            x, y = get_xy(pt)
                            vertices.add(norm_xy(x, y))
    except Exception as e:
        print(f"⚠️ Erro ao extrair vértices da geometria: {e}")

    return vertices

# ==========================================================
# Representar os vértices
# ==========================================================

def materializar_vertices(nome, vertices, crs):
    if not vertices:
        return None

    out_gpkg = os.path.join(tmpdir, f"{nome}.gpkg")
    layer_name = nome

    fields = QgsFields()
    fields.append(QgsField("vid", QVariant.Int))

    mem = QgsVectorLayer(f"Point?crs={crs.authid()}", layer_name, "memory")
    prov = mem.dataProvider()
    prov.addAttributes(fields)
    mem.updateFields()

    feats = []
    for idx, (x, y) in enumerate(sorted(vertices), start=1):
        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
        f.setFields(fields)
        f["vid"] = idx
        feats.append(f)

    prov.addFeatures(feats)
    mem.updateExtents()

    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = layer_name

    QgsVectorFileWriter.writeAsVectorFormatV2(
        mem, out_gpkg, QgsProject.instance().transformContext(), options
    )

    uri = f"{out_gpkg}|layername={layer_name}"
    #lyr = QgsVectorLayer(uri, layer_name, "ogr")
    #adiciona o temporário/memória
    lyr=mem

    if lyr.isValid():
        grupo = obter_ou_criar_grupo_resultados()
        QgsProject.instance().addMapLayer(lyr, False)
        grupo.addLayer(lyr)

    return lyr

# ==========================================================
# Representar os vértices por tipo
# ==========================================================

def materializar_geometrias_por_tipo(prefixo, geometrias_dict, crs):
    layers_saida = {}

    for chave, geoms in geometrias_dict.items():
        if not geoms:
            continue

        if chave == "point":
            tipo = "MultiPoint"
        elif chave == "line":
            tipo = "MultiLineString"
        elif chave == "polygon":
            tipo = "MultiPolygon"
        else:
            continue

        nome = f"{prefixo}_{chave}"
        out_gpkg = os.path.join(tmpdir, f"{nome}.gpkg")
        fields = QgsFields()
        fields.append(QgsField("id", QVariant.Int))

        mem = QgsVectorLayer(f"{tipo}?crs={crs.authid()}", nome, "memory")
        if not mem.isValid():
            print(f"⚠️ Não foi possível criar a camada '{nome}'.")
            continue

        prov = mem.dataProvider()
        prov.addAttributes(fields)
        mem.updateFields()

        feats = []
        for idx, geom in enumerate(geoms, start=1):
            f = QgsFeature()
            f.setGeometry(geom)
            f.setFields(fields)
            f["id"] = idx
            feats.append(f)

        prov.addFeatures(feats)
        mem.updateExtents()

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = nome

        QgsVectorFileWriter.writeAsVectorFormatV2(
            mem, out_gpkg, QgsProject.instance().transformContext(), options
        )

        uri = f"{out_gpkg}|layername={nome}"
        lyr = QgsVectorLayer(uri, nome, "ogr")

        if lyr.isValid():
            grupo = obter_ou_criar_grupo_resultados()
            QgsProject.instance().addMapLayer(lyr, False)
            grupo.addLayer(lyr)
            layers_saida[chave] = lyr

    return layers_saida

# ==========================================================
# Separação por tipo geométrico
# ==========================================================

def separar_geometria_por_tipo(geom):
    resultado = {
        "point": [],
        "line": [],
        "polygon": []
    }

    if not geom or geom.isEmpty():
        return resultado

    try:
        for part in geom.constParts():
            subgeom = QgsGeometry(part.clone())
            if not subgeom or subgeom.isEmpty():
                continue

            flat = QgsWkbTypes.flatType(subgeom.wkbType())
            gtype = QgsWkbTypes.geometryType(flat)

            if gtype == QgsWkbTypes.PointGeometry:
                multi = subgeom.coerceToType(QgsWkbTypes.MultiPoint)
                if multi:
                    for g in multi:
                        if g and not g.isEmpty():
                            resultado["point"].append(g)

            elif gtype == QgsWkbTypes.LineGeometry:
                multi = subgeom.coerceToType(QgsWkbTypes.MultiLineString)
                if multi:
                    for g in multi:
                        if g and not g.isEmpty():
                            resultado["line"].append(g)

            elif gtype == QgsWkbTypes.PolygonGeometry:
                multi = subgeom.coerceToType(QgsWkbTypes.MultiPolygon)
                if multi:
                    for g in multi:
                        if g and not g.isEmpty():
                            resultado["polygon"].append(g)

    except Exception as e:
        print(f"⚠️ Erro ao separar geometria por tipo: {e}")

    return resultado

# ==========================================================
# Intersetar as listas
# ==========================================================

def criar_intersecoes_entre_listas(camadas_a, camadas_b, nome_saida, crs):
    geometrias_por_tipo = {
        "point": [],
        "line": [],
        "polygon": []
    }
    vertices_intersecao = set()

    for camada_a in camadas_a:
        for fa in camada_a.getFeatures():
            ga = geometria_valida(fa.geometry())
            if not ga:
                continue

            for camada_b in camadas_b:
                for fb in camada_b.getFeatures():
                    gb = geometria_valida(fb.geometry())
                    if not gb:
                        continue

                    if not ga.intersects(gb):
                        continue

                    inter = ga.intersection(gb)
                    inter = geometria_valida(inter)
                    if not inter:
                        continue

                    partes = separar_geometria_por_tipo(inter)
                    for chave in geometrias_por_tipo:
                        geometrias_por_tipo[chave].extend(partes[chave])

                    vertices_intersecao |= extrair_vertices_geometria(inter)

    layers_saida = materializar_geometrias_por_tipo(nome_saida, geometrias_por_tipo, crs)
    return layers_saida, vertices_intersecao

# ==========================================================
# Principal
# ==========================================================

def confinantes():
    cam_orig = obter_camadas_do_grupo("originais")
    cam_subm = obter_camadas_do_grupo("submetidos")

    if not (cam_orig and cam_subm):
        mostrar_mensagem("Não foram encontradas camadas nos grupos 'originais' e 'submetidos'.")
        return

    crs = cam_orig[0].crs()

    print("🔍 Extraindo vértices críticos dos ORIGINAIS…")
    vc_orig = extrair_vertices_criticos(cam_orig)
    materializar_vertices("vertices_criticos_originais", vc_orig, crs)

    print("🔍 Extraindo vértices críticos dos SUBMETIDOS…")
    vc_subm = extrair_vertices_criticos(cam_subm)
    materializar_vertices("vertices_criticos_submetidos", vc_subm, crs)

    print("🔍 A calcular a diferença de vértices críticos…")
    #diferenca = vc_subm - vc_orig
    #diferenca nos dois sentidos/diferenca simetrica
    diferenca = vc_orig ^ vc_subm
    if diferenca:
        conf_erros = materializar_vertices("confinantes_erros", diferenca, crs)
    else:
        conf_erros = None
        print("✅ Não foram encontrados vértices em erro.")

    predio_subm = obter_camadas_predio(cam_subm)
    confinante_orig = obter_camadas_confinantes(cam_orig)
    predio_orig = obter_camadas_predio(cam_orig)
    confinante_subm = obter_camadas_confinantes(cam_subm)

    prd_conf_1 = {}
    prd_conf_2 = {}
    vertices_ref_1 = set()
    vertices_ref_2 = set()

    if predio_subm and confinante_orig:
        print("🔍 A gerar interseções puras prd_conf_1 separadas por geometria...")
        prd_conf_1, vertices_ref_1 = criar_intersecoes_entre_listas(
            predio_subm, confinante_orig, "prd_conf_1", crs
        )

    if predio_orig and confinante_subm:
        print("🔍 A gerar interseções puras prd_conf_2 separadas por geometria...")
        prd_conf_2, vertices_ref_2 = criar_intersecoes_entre_listas(
            predio_orig, confinante_subm, "prd_conf_2", crs
        )

    if not conf_erros:
        print("✅ Não existem pontos em 'confinantes_erros' para validar.")
        num_erros=0
        return num_erros

    vertices_referencia = vertices_ref_1 | vertices_ref_2

    vertices_erros = set()
    for feat in conf_erros.getFeatures():
        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue

        if geom.isMultipart():
            for pt in geom.asMultiPoint():
                x, y = get_xy(pt)
                vertices_erros.add(norm_xy(x, y))
        else:
            pt = geom.asPoint()
            x, y = get_xy(pt)
            vertices_erros.add(norm_xy(x, y))

    print("🔍 A comparar vértices de 'confinantes_erros' com os vértices de todas as interseções...")
    vertices_fora = {v for v in vertices_erros if v not in vertices_referencia}
    #se não fazem parte são considerados erros
    if vertices_fora:
        erro_f_layer = materializar_vertices("confinantes_erro_f", vertices_fora, crs)
        num_erros = erro_f_layer.featureCount() if erro_f_layer else len(vertices_fora)
        
        #materializar_vertices("confinantes_erro_f", vertices_fora, crs)
        print("✅ Camada 'confinantes_erro_f' adicionada ao projeto.")
    else:
        num_erros=0
        print("✅ Todos os vértices de 'confinantes_erros' pertencem aos resultados das interseções puras.")
    return num_erros  # Retorna para o programa principal
# Executar
#confinantes()
#erros = confinantes()
#print(f"Função confinantes() retornou: erros={erros}")