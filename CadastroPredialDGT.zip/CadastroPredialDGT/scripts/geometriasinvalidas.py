from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry,
    QgsPointXY, QgsField, QgsWkbTypes
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.utils import iface

def obter_camadas_submetidos():
    """Obtém apenas as camadas do grupo 'submetidos' que são GPKG de polígonos."""
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()

    grupo = root.findGroup("submetidos")
    if not grupo:
        iface.messageBar().pushWarning("submetidos", "O grupo 'submetidos' não existe.")
        return []

    camadas = []
    for node in grupo.children():
        if hasattr(node, "layer"):
            lyr = node.layer()
            if (
                lyr
                and lyr.isValid()
                and lyr.providerType() == "ogr"
                and "gpkg" in lyr.source().lower()
                and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry
            ):
                camadas.append(lyr)

    return camadas

def adicionar_resultado_ao_grupo(layer):
    """Adiciona a camada resultante ao grupo 'resultados'."""
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()

    grupo_res = root.findGroup("resultados")
    if not grupo_res:
        grupo_res = root.addGroup("resultados")

    projeto.addMapLayer(layer, addToLegend=False)
    grupo_res.addLayer(layer)

def mostrar_mensagem(texto):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setWindowTitle("Geometrias inválidas")
    msg.setText(texto)
    msg.exec_()

def detectar_auto_intersecoes():
    camadas_submetidos = obter_camadas_submetidos()

    if not camadas_submetidos:
        mensagem = "Não foram encontradas camadas GPKG de polígonos no grupo 'submetidos'."
        mostrar_mensagem(mensagem)
        return {
            "total_erros": 0,
            "camadas_com_erros": []
        }

    total_erros = 0
    pontos_erro = []
    camadas_com_erros = set()

    for lyr in camadas_submetidos:
        nome_camada = lyr.name()

        for feat in lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            rings = geom.asMultiPolygon() if geom.isMultipart() else [geom.asPolygon()]

            for poly in rings:
                for ring in poly:
                    segs = []
                    for i in range(len(ring) - 1):
                        p1, p2 = ring[i], ring[i + 1]
                        segs.append(QgsGeometry.fromPolylineXY([QgsPointXY(p1), QgsPointXY(p2)]))

                    n = len(segs)
                    for i in range(n):
                        for j in range(i + 2, n):
                            if i == 0 and j == n - 1:
                                continue

                            inter = segs[i].intersection(segs[j])

                            if not inter.isEmpty():
                                if inter.isMultipart():
                                    pts = inter.asMultiPoint()
                                else:
                                    if inter.wkbType() == QgsWkbTypes.Point:
                                        pts = [inter.asPoint()]
                                    else:
                                        pts = inter.asPolyline()

                                for pt in pts:
                                    pontos_erro.append((nome_camada, feat.id(), pt))
                                    camadas_com_erros.add(nome_camada)
                                    total_erros += 1

    if total_erros > 0:
        crs = camadas_submetidos[0].crs().authid()
        layer_err = QgsVectorLayer(f"Point?crs={crs}", "geometrias_invalidas_pts", "memory")
        pr = layer_err.dataProvider()

        pr.addAttributes([
            QgsField("camada", QVariant.String),
            QgsField("fid", QVariant.Int)
        ])
        layer_err.updateFields()

        feats = []
        for nome_camada, fid, pt in pontos_erro:
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt)))
            f.setAttributes([nome_camada, fid])
            feats.append(f)

        pr.addFeatures(feats)
        layer_err.updateExtents()

        adicionar_resultado_ao_grupo(layer_err)

        lista_camadas = ", ".join(sorted(camadas_com_erros))
        mensagem = f"Foram detetados {total_erros} erros nas camadas: {lista_camadas}"
        #mostrar_mensagem(mensagem)

        return {
            "total_erros": total_erros,
            "camadas_com_erros": sorted(camadas_com_erros)
        }

    else:
        mensagem = "Não foram detetadas geometrias inválidas."
        #mostrar_mensagem(mensagem)
        return {
            "total_erros": 0,
            "camadas_com_erros": []
        }

# Executar
#resultado = detectar_auto_intersecoes()
#print(resultado)