# ==========================================================
# Deteta se existem diferenças nos confinantes entregues.
# Identifica a quantidade de declarações de confinantes 
# bem como os seus nic
# ==========================================================
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import (
    QgsProject,
    QgsLayerTreeLayer,
    QgsVectorLayer,
    QgsFeature,
    QgsField,
    QgsWkbTypes,
    QgsSpatialIndex
)
from qgis.PyQt.QtCore import QVariant
import processing


def obter_camada_do_grupo(nome_grupo, nome_camada):
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup(nome_grupo)
    if not grupo:
        return None

    for child in grupo.children():
        if isinstance(child, QgsLayerTreeLayer):
            layer = child.layer()
            if layer and layer.name().lower() == nome_camada.lower():
                return layer
    return None


def obter_ou_criar_grupo(nome_grupo):
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup(nome_grupo)
    if not grupo:
        grupo = root.addGroup(nome_grupo)
    return grupo


def mostrar_mensagem(texto):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setWindowTitle("Declarações de Confinantes")
    msg.setText(texto)
    msg.exec_()


def diferenca_simetrica_confinantes():
    camada_originais = obter_camada_do_grupo("originais", "confinantes")
    camada_submetidos = obter_camada_do_grupo("submetidos", "confinantes")

    if not camada_originais:
        print("Erro: não foi encontrada a camada 'confinantes' no grupo 'originais'.")
        return

    if not camada_submetidos:
        print("Erro: não foi encontrada a camada 'confinantes' no grupo 'submetidos'.")
        return

    idx_nic_original = camada_originais.fields().indexFromName("nic")
    if idx_nic_original == -1:
        print("Erro: a camada 'confinantes' do grupo 'originais' não contém o campo 'nic'.")
        return

    tolerancia = 0.001
    comportamento_snap = 0

    res_sub_aj = processing.run(
        "native:snapgeometries",
        {
            "INPUT": camada_submetidos,
            "REFERENCE_LAYER": camada_originais,
            "TOLERANCE": tolerancia,
            "BEHAVIOR": comportamento_snap,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    confinantes_submetidos_ajustados = res_sub_aj["OUTPUT"]
    confinantes_submetidos_ajustados.setName("confinantes_submetidos_ajustados")

    res_ori_aj = processing.run(
        "native:snapgeometries",
        {
            "INPUT": camada_originais,
            "REFERENCE_LAYER": confinantes_submetidos_ajustados,
            "TOLERANCE": tolerancia,
            "BEHAVIOR": comportamento_snap,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    confinantes_originais_ajustados = res_ori_aj["OUTPUT"]
    confinantes_originais_ajustados.setName("confinantes_originais_ajustados")

    res_diff = processing.run(
        "native:symmetricaldifference",
        {
            "INPUT": confinantes_originais_ajustados,
            "OVERLAY": confinantes_submetidos_ajustados,
            "INPUT_FIELDS": ["nic"],
            "OVERLAY_FIELDS": [],
            "OVERLAY_FIELDS_PREFIX": "",
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_diff = res_diff["OUTPUT"]

    res_fix = processing.run(
        "native:fixgeometries",
        {
            "INPUT": camada_diff,
            "METHOD": 1,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_fix = res_fix["OUTPUT"]

    res_single = processing.run(
        "native:multiparttosingleparts",
        {
            "INPUT": camada_fix,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_single = res_single["OUTPUT"]

    crs_authid = camada_originais.crs().authid()
    geom_tipo = QgsWkbTypes.displayString(QgsWkbTypes.singleType(camada_single.wkbType()))

    camada_final = QgsVectorLayer(
        f"{geom_tipo}?crs={crs_authid}",
        "confinantes_diff_simetrica_tmp",
        "memory"
    )

    prov = camada_final.dataProvider()
    prov.addAttributes([QgsField("nic", QVariant.String)])
    camada_final.updateFields()

    indice_original = QgsSpatialIndex()
    feats_originais = {}

    for f in confinantes_originais_ajustados.getFeatures():
        feats_originais[f.id()] = f
        indice_original.addFeature(f)

    novos_feats = []
    idx_nic_resultado = camada_single.fields().indexFromName("nic")

    for feat in camada_single.getFeatures():
        geom = feat.geometry()
        nic_valor = None

        if not geom or geom.isEmpty():
            continue

        if idx_nic_resultado != -1:
            nic_valor = feat[idx_nic_resultado]

        if nic_valor in [None, ""]:
            geom_procura = geom

            try:
                geom_buffer_externo = geom.buffer(0.001, 8)
                if geom_buffer_externo and not geom_buffer_externo.isEmpty():
                    geom_procura = geom_buffer_externo
            except Exception:
                pass

            ids_candidatos = indice_original.intersects(geom_procura.boundingBox())
            melhor_id = None
            melhor_area = 0

            for fid in ids_candidatos:
                feat_orig = feats_originais[fid]
                geom_orig = feat_orig.geometry()

                if not geom_orig or geom_orig.isEmpty() or not geom_orig.isGeosValid():
                    continue

                intersecao = geom_procura.intersection(geom_orig)
                if intersecao and not intersecao.isEmpty():
                    area_intersecao = intersecao.area()
                    if area_intersecao > melhor_area:
                        melhor_area = area_intersecao
                        melhor_id = fid

            if melhor_id is not None:
                nic_valor = feats_originais[melhor_id]["nic"]

        novo_feat = QgsFeature(camada_final.fields())
        novo_feat.setGeometry(geom)
        novo_feat["nic"] = None if nic_valor in [None, ""] else str(nic_valor)
        novos_feats.append(novo_feat)

    prov.addFeatures(novos_feats)
    camada_final.updateExtents()

    expr_espessura = '(4 * pi() * $area) / ($perimeter * $perimeter) > 0'

    total_antes = camada_final.featureCount()

    res_filtrado = processing.run(
        "native:extractbyexpression",
        {
            "INPUT": camada_final,
            "EXPRESSION": expr_espessura,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_filtrada = res_filtrado["OUTPUT"]

    total_pos_espessura = camada_filtrada.featureCount()
    total_eliminados_espessura = total_antes - total_pos_espessura

    expr_area_minima = '$area >= 0.0001'

    res_area = processing.run(
        "native:extractbyexpression",
        {
            "INPUT": camada_filtrada,
            "EXPRESSION": expr_area_minima,
            "OUTPUT": "TEMPORARY_OUTPUT"
        }
    )

    camada_filtrada_area = res_area["OUTPUT"]
    camada_filtrada_area.setName("confinantes_diff_simetrica")

    total_final = camada_filtrada_area.featureCount()
    total_eliminados_area = total_pos_espessura - total_final

    valores_nic = set()
    for feat in camada_filtrada_area.getFeatures():
        nic = feat["nic"]
        if nic not in [None, ""]:
            valores_nic.add(str(nic))

    valores_nic_ordenados = sorted(valores_nic)
    numero_declaracoes = len(valores_nic_ordenados)

    print(f"Foram eliminados {total_eliminados_espessura} polígonos pelo critério de espessura.")
    print(f"Foram eliminados {total_eliminados_area} polígonos com área inferior a 0.0001 m².")
    print(f"Serão necessárias {numero_declaracoes} declarações de confinantes.")

    if valores_nic_ordenados:
        lista_nics = ", ".join(valores_nic_ordenados)

        if numero_declaracoes == 1:
            msg_dc = f"Será necessária 1 declaração de confinantes com o prédio nic: {lista_nics}"
        else:
            msg_dc = f"Serão necessárias {numero_declaracoes} declarações de confinantes com os prédios nic: {lista_nics}"

        print("Mensagem das declarações de confinantes:",msg_dc)

        projeto = QgsProject.instance()
        projeto.addMapLayer(camada_filtrada_area, False)
        grupo_resultados = obter_ou_criar_grupo("resultados")
        grupo_resultados.addLayer(camada_filtrada_area)
    else:
        msg_dc = "Não será exigida qualquer declaração de confinantes."
        #mostrar_mensagem(msg_dc)

    return msg_dc


# Executar
#diferenca_simetrica_confinantes()