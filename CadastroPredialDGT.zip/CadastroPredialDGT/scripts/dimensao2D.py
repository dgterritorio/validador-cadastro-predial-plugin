# ==========================================================
# Verifica se a dimensão das camadas é 2D
# ==========================================================
from qgis.core import QgsWkbTypes, QgsProject
from qgis.utils import iface
from PyQt5.QtCore import QVariant
from PyQt5.QtWidgets import QMessageBox

# ==========================================================
# Utilitários
# ==========================================================

def obter_camadas_submetidos():
    """Obtém apenas as camadas do grupo 'submetidos' que são GPKG de polígonos."""
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()

    grupo = root.findGroup("submetidos")
    if not grupo:
        iface.messageBar().pushWarning("submetidos", "O grupo 'submetidos' não existe.")
        return []

    camadas = []
    for node in grupo.children():
        if hasattr(node, "layer"):
            lyr = node.layer()
            if (
                lyr
                and lyr.isValid()
                and lyr.providerType() == "ogr"
                and "gpkg" in lyr.source().lower()
                and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry
            ):
                camadas.append(lyr)

    return camadas


def is_layer_2d(layer):
    """Verifica se a camada é polígono 2D (sem Z e sem M)."""
    geom_type = layer.wkbType()
    if QgsWkbTypes.geometryType(geom_type) == QgsWkbTypes.PolygonGeometry:
        return not (QgsWkbTypes.hasZ(geom_type) or QgsWkbTypes.hasM(geom_type))
    return None


def mostrar_mensagem(texto):
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Dimensão 2D")
    msg_box.setText(texto)
    msg_box.exec_()


# ============================================================
# Verificar as camadas do grupo "submetidos"
# ============================================================

def verificar_camadas_submetidos_2d():
    """Verifica apenas as camadas GPKG de polígonos que estão no grupo 'submetidos'."""

    print("🔍 A Verificar as camadas de polígonos GPKG no grupo 'submetidos'...")

    camadas_submetidos = obter_camadas_submetidos()
    camadas_nao_2d = []

    if not camadas_submetidos:
        iface.messageBar().pushInfo(
            "Verificação",
            "Nenhuma camada GPKG de polígonos encontrada no grupo 'submetidos'."
        )
        mostrar_mensagem("Nenhuma camada GPKG de polígonos encontrada no grupo 'submetidos'.")
        return

    for layer in camadas_submetidos:
        resultado = is_layer_2d(layer)

        if resultado is True:
            print(f"✅ Camada '{layer.name()}' é 2D.")
        elif resultado is False:
            print(f"⚠️ Camada '{layer.name()}' NÃO é 2D (possui Z ou M).")
            camadas_nao_2d.append(layer.name())
        else:
            print(f"ℹ️ Camada '{layer.name()}' não é um polígono.")

# ==========================================================
# Mensagens finais
# ==========================================================
    if camadas_nao_2d:
        
        mensagem="A camada não está 2D: " + ",".join(camadas_nao_2d)
        return mensagem
    else:
        
        mensagem="0"
        return mensagem
# Executar
#verificar_camadas_submetidos_2d()
