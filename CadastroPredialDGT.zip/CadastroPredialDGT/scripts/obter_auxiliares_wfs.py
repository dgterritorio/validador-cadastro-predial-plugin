# ==========================================================
# Obtem prédios da carta cadastral que se intersectam com os prédios/confinantes submetidos.
# Utiliza o serviço WFS - inspire:cadastralparcel
# O prédios obtidos com o mesmo nic dos prédios originais são ignorados
# ==========================================================
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QUrl, QEventLoop
from qgis.PyQt.QtNetwork import QNetworkRequest, QNetworkAccessManager
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsVectorFileWriter,
    QgsWkbTypes,
    QgsCoordinateTransform,
    QgsCoordinateReferenceSystem,
)
from qgis import processing
import tempfile
import os

#dados do serviço wms
WFS_URL = "https://snicws.dgterritorio.gov.pt/geoserver/inspire/ows"
WFS_TYPENAME = "inspire:cadastralparcel"
#camadas de saída
NOME_SAIDA = "auxiliares"
NOME_SAIDA_FINAL = "auxiliares_confinantes"
SRS_WFS = "EPSG:3763"


def mostrar_mensagem(txt):
    QMessageBox.information(None, "Auxiliares WFS", txt)


def obter_grupo(nome):
    return QgsProject.instance().layerTreeRoot().findGroup(nome)


def obter_ou_criar_grupo_resultados():
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup("resultados")
    if not grupo:
        grupo = root.addGroup("resultados")
    return grupo


def obter_camadas_poligono_do_grupo(nome_grupo):
    grupo = obter_grupo(nome_grupo)
    if not grupo:
        return []

    camadas = []
    for node in grupo.children():
        if hasattr(node, "layer"):
            lyr = node.layer()
            if lyr and lyr.isValid():
                if QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry:
                    camadas.append(lyr)
    return camadas


def obter_camadas_por_nome(nome_grupo, nomes_validos):
    grupo = obter_grupo(nome_grupo)
    if not grupo:
        return []

    camadas = []
    nomes_validos = [n.lower() for n in nomes_validos]

    for node in grupo.children():
        if hasattr(node, "layer"):
            lyr = node.layer()
            if lyr and lyr.isValid():
                nome = lyr.name().lower().strip()
                if nome in nomes_validos:
                    camadas.append(lyr)

    return camadas


def recolher_nics_originais():
    camadas = obter_camadas_por_nome("originais", ["predio", "confinantes"])
    nics = set()

    for lyr in camadas:
        idx = lyr.fields().indexOf("nic")
        if idx == -1:
            continue

        for feat in lyr.getFeatures():
            val = feat["nic"]
            if val is None:
                continue

            txt = str(val).strip()
            if txt:
                nics.add(txt)

    print(f"➡ NIC dos prédios originais: {len(nics)}")
    return nics


def criar_geometria_unida(camadas):
    geom_total = None

    for lyr in camadas:
        for feat in lyr.getFeatures():
            geom = feat.geometry()
            if not geom or geom.isEmpty():
                continue

            if geom_total is None:
                geom_total = QgsGeometry(geom)
            else:
                geom_total = geom_total.combine(geom)

    return geom_total


def construir_url_getfeature(bbox_txt):
    return (
        f"{WFS_URL}"
        f"?service=WFS"
        f"&version=2.0.0"
        f"&request=GetFeature"
        f"&typeNames={WFS_TYPENAME}"
        f"&srsName={SRS_WFS}"
        f"&outputFormat=application/json"
        f"&bbox={bbox_txt}"
    )


def descarregar_geojson(url):
    manager = QNetworkAccessManager()
    request = QNetworkRequest(QUrl(url))
    reply = manager.get(request)

    loop = QEventLoop()
    reply.finished.connect(loop.quit)
    loop.exec_()

    if reply.error():
        erro = reply.errorString()
        reply.deleteLater()
        raise Exception(f"Erro no pedido WFS: {erro}")

    data = bytes(reply.readAll()).decode("utf-8")
    reply.deleteLater()
    return data


def guardar_resultado_gpkg(features, fields, wkb_type, crs, nome_saida):
    if not features:
        return None

    tmpdir = tempfile.mkdtemp(prefix="qgis_aux_wfs_")
    gpkg_saida = os.path.join(tmpdir, f"{nome_saida}.gpkg")

    tipo_mem = QgsWkbTypes.displayString(wkb_type)
    mem = QgsVectorLayer(f"{tipo_mem}?crs={crs.authid()}", nome_saida, "memory")
    prov = mem.dataProvider()
    prov.addAttributes(fields)
    mem.updateFields()
    prov.addFeatures(features)
    mem.updateExtents()

    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GPKG"
    opts.layerName = nome_saida

    QgsVectorFileWriter.writeAsVectorFormatV2(
        mem,
        gpkg_saida,
        QgsProject.instance().transformContext(),
        opts
    )

    lyr_out = QgsVectorLayer(f"{gpkg_saida}|layername={nome_saida}", nome_saida, "ogr")

    if lyr_out.isValid():
        grupo_res = obter_ou_criar_grupo_resultados()
        QgsProject.instance().addMapLayer(lyr_out, False)
        grupo_res.addLayer(lyr_out)
        return lyr_out

    return None


def snap_layers(origem, referencia, nome_saida, tolerancia=0.001):
    print(f"→ Snap: {origem.name()} → {referencia.name()}")

    params = {
        "INPUT": origem,
        "REFERENCE_LAYER": referencia,
        "TOLERANCE": tolerancia,
        "BEHAVIOR": 0,
        "OUTPUT": "memory:"
    }

    result = processing.run("native:snapgeometries", params)
    layer = result["OUTPUT"]
    layer.setName(nome_saida)

    print(f"✔ Snap concluído: {nome_saida}")
    return layer


def obter_auxiliares_wfs():
    camadas_submetidos = obter_camadas_poligono_do_grupo("submetidos")

    if not camadas_submetidos:
        mostrar_mensagem("Não foram encontradas camadas de polígonos no grupo 'submetidos'.")
        return

    print(f"➡ Camadas encontradas em 'submetidos': {[lyr.name() for lyr in camadas_submetidos]}")

    nics_originais = recolher_nics_originais()

    geom_ref = criar_geometria_unida(camadas_submetidos)
    if not geom_ref or geom_ref.isEmpty():
        mostrar_mensagem("Não foi possível construir a geometria de referência do grupo 'submetidos'.")
        return

    crs_ref = camadas_submetidos[0].crs()
    geom_ref_wfs = QgsGeometry(geom_ref)
    crs_wfs = QgsCoordinateReferenceSystem(SRS_WFS)

    if crs_ref != crs_wfs:
        tr = QgsCoordinateTransform(crs_ref, crs_wfs, QgsProject.instance())
        geom_ref_wfs.transform(tr)

    bbox = geom_ref_wfs.boundingBox()
    bbox_txt = f"{bbox.xMinimum()},{bbox.yMinimum()},{bbox.xMaximum()},{bbox.yMaximum()},{SRS_WFS}"
    url = construir_url_getfeature(bbox_txt)

    print("➡ Pedido WFS direto por BBOX...")
    print(url)

    try:
        geojson_txt = descarregar_geojson(url)
    except Exception as e:
        mostrar_mensagem(str(e))
        return

    tmp_geojson = os.path.join(tempfile.mkdtemp(prefix="qgis_wfs_json_"), "wfs_result.geojson")
    with open(tmp_geojson, "w", encoding="utf-8") as f:
        f.write(geojson_txt)

    lyr_json = QgsVectorLayer(tmp_geojson, "auxiliares", "ogr")
    if not lyr_json.isValid():
        mostrar_mensagem("Não foi possível ler o GeoJSON devolvido pelo serviço WFS.")
        return

    print(f"➡ Prédios devolvidas pelo WFS: {lyr_json.featureCount()}")

    idx_ncr = lyr_json.fields().indexOf("nationalcadastralreference")
    if idx_ncr == -1:
        mostrar_mensagem("O campo 'nationalcadastralreference' não existe nos dados do serviço WFS.")
        return

    feats_saida = []
    fields = lyr_json.fields()
    wkb_type = lyr_json.wkbType()

    total_intersetam = 0
    total_descartados_nic = 0

    for feat in lyr_json.getFeatures():
        geom = feat.geometry()
        if not geom or geom.isEmpty():
            continue

        if not geom.intersects(geom_ref_wfs):
            continue

        total_intersetam += 1

        ncr = feat["nationalcadastralreference"]
        ncr_txt = "" if ncr is None else str(ncr).strip()

        if ncr_txt and ncr_txt in nics_originais:
            total_descartados_nic += 1
            continue

        novo = QgsFeature(fields)
        novo.setGeometry(geom)
        novo.setAttributes(feat.attributes())
        feats_saida.append(novo)

    print(f"➡ Prédios após interseção: {total_intersetam}")
    print(f"➡ Prédios descartados por NIC já existente: {total_descartados_nic}")
    print(f"➡ Prédios finais para gravar: {len(feats_saida)}")

    if not feats_saida:
        mostrar_mensagem("Não existem prédios para guardar após excluir os NIC já existentes nos dados originais.")
        return

    aux_layer = guardar_resultado_gpkg(feats_saida, fields, wkb_type, crs_wfs, NOME_SAIDA)
    if not aux_layer:
        mostrar_mensagem("O GeoPackage inicial não pôde ser criado.")
        return

    confinantes = obter_camadas_por_nome("originais", ["confinantes"])
    if not confinantes:
        mostrar_mensagem("Não foi encontrada a camada 'confinantes' no grupo 'originais'.")
        return

    aux_snapped = snap_layers(aux_layer, confinantes[0], NOME_SAIDA_FINAL, tolerancia=0.001)

    if not aux_snapped or not aux_snapped.isValid():
        mostrar_mensagem("Não foi possível aplicar snap ao resultado 'auxiliares'.")
        return

    final_fields = aux_snapped.fields()
    final_wkb_type = aux_snapped.wkbType()
    final_crs = aux_snapped.crs()

    final_layer = guardar_resultado_gpkg(
        [feat for feat in aux_snapped.getFeatures()],
        final_fields,
        final_wkb_type,
        final_crs,
        NOME_SAIDA_FINAL
    )

    if final_layer:
        #mostrar_mensagem(f"Camada '{NOME_SAIDA_FINAL}' criada e adicionada ao grupo 'resultados'.")
        msg_wfs=(f"Camada '{NOME_SAIDA_FINAL}' criada e adicionada ao grupo 'resultados'.")
    else:
        #mostrar_mensagem("Não foi possível criar a camada final ajustada aos confinantes.")
        msg_wfs=(f"Camada '{NOME_SAIDA_FINAL}' criada e adicionada ao grupo 'resultados'.")
    return msg_wfs
#obter_auxiliares_wfs()
