# ==========================================================
# Verifica se a distância entre vértices nas camadas geopackage
# existentes no grupo "submetidos" tem uma distância inferior à introduzida.
# Tolerância recomendada é de 1 mm.
# ==========================================================
from qgis.core import (
    QgsProject,
    QgsGeometry,
    QgsPointXY,
    QgsVectorLayer,
    QgsWkbTypes,
    QgsFeature,
    QgsField,
    QgsCoordinateReferenceSystem
)
from PyQt5.QtCore import QVariant
from PyQt5.QtWidgets import QMessageBox, QInputDialog


# ==========================================================
# Utilitários
# ==========================================================

def obter_camadas_submetidos():
    """
    Retorna apenas as camadas de polígonos GeoPackage
    que estão dentro do grupo 'submetidos' no QGIS.
    """
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()
    grupo = root.findGroup("submetidos")

    if not grupo:
        QMessageBox.warning(None, "Aviso",
                            "O grupo 'submetidos' não existe no projeto.")
        return []

    camadas_poligonos = []

    for node in grupo.children():
        if hasattr(node, "layer"):
            layer = node.layer()
            if isinstance(layer, QgsVectorLayer):
                if layer.geometryType() == QgsWkbTypes.PolygonGeometry:
                    if ".gpkg" in layer.source().lower():
                        camadas_poligonos.append(layer)

    return camadas_poligonos


def distancia_menor_que_tolerancia(p1, p2, tolerancia):
    distancia = p1.distance(p2)
    return 0 < distancia < tolerancia


def obter_vertices(geometria):
    if not geometria or geometria.isEmpty():
        return []
    
    vertices = []
    if geometria.isMultipart():
        partes = geometria.asMultiPolygon()
    else:
        partes = [geometria.asPolygon()]
    
    for poligono in partes:
        for anel in poligono:
            vertices.extend(anel)
    
    return vertices


def criar_camada_memoria_pontos(pontos_proximos):
    """Cria uma camada de memória com os pontos próximos detectados
       e adiciona ao grupo 'resultados' do projeto QGIS.
    """

    crs = QgsCoordinateReferenceSystem("EPSG:3763")
    camada_pontos = QgsVectorLayer(
        f"Point?crs={crs.authid()}",
        "Vértices Próximos",
        "memory"
    )
    prov = camada_pontos.dataProvider()
    
    prov.addAttributes([
        QgsField("camada1", QVariant.String),
        QgsField("feicao1", QVariant.Int),
        QgsField("camada2", QVariant.String),
        QgsField("feicao2", QVariant.Int),
        QgsField("distancia", QVariant.Double)
    ])
    camada_pontos.updateFields()

    for ponto, dados in pontos_proximos:
        feat = QgsFeature()
        feat.setGeometry(QgsGeometry.fromPointXY(ponto))
        feat.setAttributes([
            dados["camada1"],
            dados["feicao1"],
            dados["camada2"],
            dados["feicao2"],
            dados["distancia"]
        ])
        prov.addFeature(feat)

    camada_pontos.updateExtents()

    # Adicionar ao projeto QGIS
    QgsProject.instance().addMapLayer(camada_pontos, addToLegend=False)

    # dicionar ao grupo "resultados"
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()

    grupo = root.findGroup("resultados")
    if not grupo:
        # criar o grupo caso ainda não exista
        grupo = root.addGroup("resultados")

    grupo.addLayer(camada_pontos)


def mostrar_mensagem(texto):
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Distância entre vértices")
    msg_box.setText(texto)
    msg_box.exec_()


def verificar_vertices_proximos(tolerancia_dist):

    tolerancia = tolerancia_dist

    # 🔵 Agora só considera camadas do grupo "submetidos"
    camadas = obter_camadas_submetidos()

    if not camadas:
        mostrar_mensagem("Nenhuma camada válida encontrada no grupo 'submetidos'.")
        return

    pontos_proximos = []

    for i, camada1 in enumerate(camadas):

        for feicao1 in camada1.getFeatures():
            if not feicao1.geometry():
                continue

            vertices1 = obter_vertices(feicao1.geometry())

            # verificar vértices dentro da mesma camada
            for a in range(len(vertices1)):
                for b in range(a + 1, len(vertices1)):
                    if distancia_menor_que_tolerancia(vertices1[a], vertices1[b], tolerancia):
                        pontos_proximos.append(
                            (vertices1[a],
                             {"camada1": camada1.name(),
                              "feicao1": feicao1.id(),
                              "camada2": camada1.name(),
                              "feicao2": feicao1.id(),
                              "distancia": vertices1[a].distance(vertices1[b])})
                        )

        # comparar com outras camadas
        for camada2 in camadas[i+1:]:
            for feicao1 in camada1.getFeatures():
                if not feicao1.geometry():
                    continue
                vertices1 = obter_vertices(feicao1.geometry())

                for feicao2 in camada2.getFeatures():
                    if not feicao2.geometry():
                        continue
                    vertices2 = obter_vertices(feicao2.geometry())

                    for v1 in vertices1:
                        for v2 in vertices2:
                            if distancia_menor_que_tolerancia(v1, v2, tolerancia):
                                pontos_proximos.append(
                                    (v1,
                                     {"camada1": camada1.name(),
                                      "feicao1": feicao1.id(),
                                      "camada2": camada2.name(),
                                      "feicao2": feicao2.id(),
                                      "distancia": v1.distance(v2)})
                                )

    pontos_proximos = [p for p in pontos_proximos if p[1]["distancia"] > 0]

    if pontos_proximos:
        criar_camada_memoria_pontos(pontos_proximos)
        msg=(f"{len(pontos_proximos)}")
    else:
        
        msg=(f"{len(pontos_proximos)}")

    #mostrar_mensagem(msg)
    return msg

# Alterar a tolerância na função seguinte para o caso de utilização do script
#verificar_vertices_proximos(0.001)
