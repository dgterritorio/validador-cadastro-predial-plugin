# ==========================================================
# Corrigir o geopackage submetido:
# 1.Eliminar vértices duplicados
# 2.Corrigir geometrias inválidas
# 3.Ajustar camadas
# 4.Escreve um novo geopackage
# ==========================================================
from qgis.core import *
from qgis.PyQt.QtCore import QVariant
import os
import processing
from qgis.core import QgsProject, QgsLayerTreeLayer
from qgis.gui import QgsLayerTreeMapCanvasBridge
from qgis.core import (QgsVectorFileWriter, QgsCoordinateTransformContext,QgsWkbTypes)
from qgis.utils import iface


# ==========================================================
# CONFIGURAÇÃO
# ==========================================================

CRS = "EPSG:3763"

CAMADAS_BASE = [
    "predio",
    "confinantes",
    "dominio_publico",
    "area_nao_cadastrada",
    "dominio_publico_confinante",
    "adicionais"
]

GRUPO_ORIGINAIS = "originais"
GRUPO_SUBMETIDOS = "submetidos"
GRUPO_CORRIGIDOS = "corrigidos"
GRUPO_RESULTADOS = "resultados"

# ==========================================================
# UTILITÁRIOS:
# ==========================================================

def obter_grupo(nome):
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup(nome)
    
    return grupo or root.addGroup(nome)

def obter_camada(nome, grupo_nome):
    grupo = QgsProject.instance().layerTreeRoot().findGroup(grupo_nome)
    if not grupo:
        print(f"❌ Grupo '{grupo_nome}' não encontrado.")
        return None

    for child in grupo.children():
        if isinstance(child, QgsLayerTreeLayer):
            if child.layer().name() == nome:
                print(f"✔ Camada encontrada: {nome} ({grupo_nome})")
                return child.layer()

    print(f"❌ Camada '{nome}' não encontrada em '{grupo_nome}'.")
    return None
    
def mostrar_mensagem(texto):
    """Exibe uma caixa de diálogo com a mensagem."""
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Correção dos dados")
    msg_box.setText(texto)
    msg_box.exec_()

def adicionar_ao_grupo(camada, grupo_nome):
    grupo = obter_grupo(grupo_nome)
    QgsProject.instance().addMapLayer(camada, False)
    grupo.addLayer(camada)
    print(f"✔ Adicionada ao grupo '{grupo_nome}': {camada.name()}")

def remover_grupo(nome_grupo):
    project = QgsProject.instance()
    root = project.layerTreeRoot()

    grupo = root.findGroup(nome_grupo)
    if not grupo:
        print(f"Grupo '{nome_grupo}' não encontrado.")
        return

    # Remover as camadas do projeto
    for child in list(grupo.children()):
        if isinstance(child, QgsLayerTreeLayer):
            layer = child.layer()
            if layer:
                project.removeMapLayer(layer.id())

    # Remover o próprio grupo
    root.removeChildNode(grupo)

    print(f"Grupo '{nome_grupo}' e respetivas camadas removidos.")


def ativar_contador_grupo_corrigidos():
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup("corrigidos")
    if not grupo:
        print("Grupo 'corrigidos' não encontrado.")
        return

    for child in grupo.children():
        if isinstance(child, QgsLayerTreeLayer):
            child.setCustomProperty("showFeatureCount", True)

    print("Contador ativado para todas as camadas do grupo 'corrigidos'.")


def atualizar_contadores_grupo(nome_grupo="corrigidos"):
    project = QgsProject.instance()
    root = project.layerTreeRoot()
    grupo = root.findGroup(nome_grupo)
    if not grupo:
        print(f"Grupo '{nome_grupo}' não encontrado.")
        return

    for child in grupo.children():
        if isinstance(child, QgsLayerTreeLayer):
            # ativar contador no nó
            child.setCustomProperty("showFeatureCount", True)

            layer = child.layer()
            if layer:
                # força o cálculo da contagem (mesmo que já exista)
                _ = layer.featureCount()

    print(f"Contadores ativados/atualizados para o grupo '{nome_grupo}'.")


# ==========================================================
# 1Remover vértices duplicados 2.Corrigir geometrias inválidas
# ==========================================================

def clean_polygons(layer_in, nome_saida,
                   tol_vertices=0.0,
                   remove_dups=True,
                   fix_geom=True):
    """
    layer_in      : QgsVectorLayer de entrada (polígonos)
    nome_saida    : nome da camada de saída em memória
    tol_vertices  : tolerância para remover vértices duplicados (0 = estritamente coincidentes)
    remove_dups   : se True, corre 'Remove duplicate vertices'
    fix_geom      : se True, corre 'Fix geometries'
    """
    layer_atual = layer_in

    # 1) Remover vértices duplicados (se pedido)
    if remove_dups:
        print(f"→ Remover vértices duplicados: {layer_in.name()}")
        params_dups = {
            "INPUT": layer_atual,
            "TOLERANCE": tol_vertices,
            "OUTPUT": "memory:"
        }
        res_dups = processing.run("native:removeduplicatevertices", params_dups)
        layer_atual = res_dups["OUTPUT"]
        print("✔ Vértices duplicados removidos")

    # 2) Corrigir geometrias inválidas (se pedido)
    if fix_geom:
        print(f"→ Corrigir geometrias inválidas: {layer_atual.name()}")
        params_fix = {
            "INPUT": layer_atual,
            "METHOD": 0,           # método padrão do QGIS
            "OUTPUT": "memory:"
        }
        res_fix = processing.run("native:fixgeometries", params_fix)
        layer_atual = res_fix["OUTPUT"]
        print("✔ Geometrias corrigidas")

    # 3) Dar nome à camada de saída
    layer_atual.setName(nome_saida)
    print(f"✔ Camada limpa: {nome_saida}")

    return layer_atual

def clean_layer(origem, nome_saida, tol_vertices=0.0):
    return clean_polygons(origem, nome_saida, tol_vertices, True, True)

# ==========================================================
# Criar geopackage vazio, sem dados.
# ==========================================================
def criar_gpkg_vazio(diretorio_corrigido, camadas, crs):

    if os.path.exists(diretorio_corrigido):
        os.remove(diretorio_corrigido)

    print(f"→ Criar GPKG: {diretorio_corrigido}")

    for i, nome in enumerate(camadas):
        uri = f"Polygon?crs={crs}"
        #layer = QgsVectorLayer(f"Polygon?crs={crs}", nome, "memory")
        layer = QgsVectorLayer(uri, nome, "memory")

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.layerName = nome
        # GARANTIR Polygon 2D no GPKG
        #options.overrideGeometryType = Qgis.WkbType.Polygon  # Polygon simples 2D
        options.overrideGeometryType = QgsWkbTypes.Polygon
        options.forceMulti = False
        options.includeZ = False
        
        options.actionOnExistingFile = (
            QgsVectorFileWriter.CreateOrOverwriteFile
            if i == 0 else
            QgsVectorFileWriter.CreateOrOverwriteLayer
        )

        res = QgsVectorFileWriter.writeAsVectorFormatV3(
            layer, diretorio_corrigido, QgsCoordinateTransformContext(), options
        )

        if res[0] != QgsVectorFileWriter.NoError:
            raise RuntimeError(f"Erro ao criar camada {nome}: {res}")

        print(f"✔ Criada camada vazia: {nome}")

    print("=== ✔ GPKG criado com sucesso ===\n")


def converter_para_polygon_single_2d(camada):
    """
    Devolve uma nova camada em memória com os mesmos poligonos,
    Polygon 2D single (sem Multi, sem Z/M).
    Cada parte de um MultiPolygon origina um poligono.
    """
    crs = camada.crs()
    campos = camada.fields()

    vl = QgsVectorLayer(f"Polygon?crs={crs.authid()}", camada.name() + "_2d", "memory")
    prov = vl.dataProvider()
    prov.addAttributes(campos)
    vl.updateFields()

    novas_feats = []

    for f in camada.getFeatures():
        geom = f.geometry()
        if not geom or geom.isEmpty():
            continue

        wkb = geom.wkbType()

        if QgsWkbTypes.isMultiType(wkb):
            # MultiPolygon (com ou sem Z/M) → lista de partes
            multi = geom.asMultiPolygon()    # devolve [[ [pt1, pt2, ...] , ... ], ...]
            for pol in multi:
                g2d = QgsGeometry.fromPolygonXY(pol)  # Polygon 2D
                nf = QgsFeature(vl.fields())
                nf.setAttributes(f.attributes())
                nf.setGeometry(g2d)
                novas_feats.append(nf)
        else:
            # Polygon (com ou sem Z/M)
            pol = geom.asPolygon()           # devolve [ [pt1, pt2, ...], ... ]
            if not pol:
                continue
            g2d = QgsGeometry.fromPolygonXY(pol)      # 2D
            nf = QgsFeature(vl.fields())
            nf.setAttributes(f.attributes())
            nf.setGeometry(g2d)
            novas_feats.append(nf)

    prov.addFeatures(novas_feats)
    vl.updateExtents()
    return vl

# ==========================================================
# Escrever no geopackage 
# ==========================================================
def escrever_no_gpkg(camada, nome_layer,diretorio_corrigido):
    options = QgsVectorFileWriter.SaveVectorOptions()
    options.driverName = "GPKG"
    options.layerName = nome_layer
    #options.overrideGeometryType = Qgis.WkbType.Polygon  # Polygon simples 2D
    options.overrideGeometryType = QgsWkbTypes.Polygon
    options.forceMulti = False  # NÃO permitir MultiPolygon
    options.includeZ = False            # sem Z
    options.includeM = False            # sem M
    options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
    options.layerOptions = ["FID="]    # GPKG cria o fid automaticamente

    res = QgsVectorFileWriter.writeAsVectorFormatV3(
        camada, diretorio_corrigido, QgsCoordinateTransformContext(), options
    )

    if res[0] == QgsVectorFileWriter.NoError:
        print(f"✔ Escrito no GPKG: {nome_layer}")
    else:
        print(f"❌ Erro ao escrever {nome_layer}: {res}")

# ==========================================================
# Adicionar geopackage ao projeto QGIS 
# ==========================================================
def adicionar_gpkg_ao_projeto(gpkg_path, camadas, grupo_nome):
    grupo = obter_grupo(grupo_nome)

    for nome in camadas:
        layer = QgsVectorLayer(f"{gpkg_path}|layername={nome}", nome, "ogr")
        QgsProject.instance().addMapLayer(layer, False)
        grupo.addLayer(layer)

    print(f"✔ GPKG adicionado ao grupo '{grupo_nome}'\n")


# ==========================================================
# Ajustar camadas
# ==========================================================

def snap_layers(origem, referencia, nome_saida, tolerancia=0.001):
    print(f"→ Snap: {origem.name()} → {referencia.name()}")

    # 1) snap
    params = {
        "INPUT": origem,
        "REFERENCE_LAYER": referencia,
        "TOLERANCE": tolerancia,
        "BEHAVIOR": 0,
        "OUTPUT": "memory:"
    }
    result = processing.run("native:snapgeometries", params)
    layer_snap = result["OUTPUT"]
    layer_snap.setName(nome_saida)

    # 2) fix geometries no resultado do snap (para evitar QgsProcessingException depois)
    print(f"→ Fix geometries após snap: {nome_saida}")
    params_fix = {
        "INPUT": layer_snap,
        "METHOD": 0,
        "OUTPUT": "memory:"
    }
    res_fix = processing.run("native:fixgeometries", params_fix)
    layer_fix = res_fix["OUTPUT"]
    layer_fix.setName(nome_saida)

    print(f"✔ Snap concluído e geometrias corrigidas: {nome_saida}")
    return layer_fix

# ==========================================================
# Execução do ajuste
# ==========================================================

def executar_processo_ajuste(diretorio_corrigido):
    # mensagem a informar que está em processamento
    iface.messageBar().pushMessage("Corrigir gpkg", "Em processamento a correcção...", level=Qgis.Info, duration=0)
    print("\n=== INÍCIO DO PROCESSO ===\n")

    # 1) Criar GPKG vazio e adicionar ao projeto QGIS
    criar_gpkg_vazio(diretorio_corrigido, CAMADAS_BASE, CRS)
    
    adicionar_gpkg_ao_projeto(diretorio_corrigido, CAMADAS_BASE, GRUPO_CORRIGIDOS)
    
    # 2) Obter camadas de entrada
    confinantes_orig = obter_camada("confinantes", GRUPO_ORIGINAIS)
    confinantes_sub = obter_camada("confinantes", GRUPO_SUBMETIDOS)
    predio = obter_camada("predio", GRUPO_SUBMETIDOS)
    dom_pub = obter_camada("dominio_publico", GRUPO_SUBMETIDOS)
    anc = obter_camada("area_nao_cadastrada", GRUPO_SUBMETIDOS)
    dom_pub_conf = obter_camada("dominio_publico_confinante", GRUPO_SUBMETIDOS)
    adicionais = obter_camada("adicionais", GRUPO_SUBMETIDOS)

    # Validação mínima
    entradas = [
        confinantes_orig, confinantes_sub, predio,
        dom_pub, anc, dom_pub_conf
    ]
    if any(c is None for c in entradas):
        raise RuntimeError("❌ Falta uma ou mais camadas obrigatórias.")

   #  3.1Corrigir confinantes, predios, dominio_publico_area_nao cadastrada submetido
    confinantes_clean = clean_layer(confinantes_sub, "confinantes_clean", tol_vertices=0.0)
    predio_clean = clean_layer(predio, "predio_clean", tol_vertices=0.0)
    area_nao_cadastrada_clean = clean_layer(anc, "area_nao_cadastrada_clean", tol_vertices=0.0)
    dominio_publico_clean = clean_layer(dom_pub, "dominio_publico_clean", tol_vertices=0.0)

    # 3.2) Fluxo de ajustes
    confinantes_aj = snap_layers(confinantes_clean, confinantes_orig, "confinantes_aj")
    predio_1 = snap_layers(predio_clean, predio_clean, "predio_aj1")
    predio_2 = snap_layers(predio_1, confinantes_aj, "predio_aj2")
    confinantes_2 = snap_layers(confinantes_aj, predio_2, "confinantes_2")
    dom_pub_1 = snap_layers(dominio_publico_clean, predio_2, "dominio_publico_1")
    dom_pub_2 = snap_layers(dom_pub_1, confinantes_2, "dominio_publico_2")
    area_nao_cadastrada_1 = snap_layers(area_nao_cadastrada_clean, predio_2, "area_nao_cadastrada_1")
    predio_3 = snap_layers(predio_2, dom_pub_2, "predio_aj3")
    predio_4 = snap_layers(predio_3, area_nao_cadastrada_1, "predio_aj4")
    confinantes_3 = snap_layers(confinantes_2, area_nao_cadastrada_1, "confinantes_3")
    
    confinantes_4 = snap_layers(confinantes_3, dom_pub_2, "confinantes_4")

    # 4) Escrever resultados no GPKG
    predio_5 = converter_para_polygon_single_2d(predio_4)
    escrever_no_gpkg(predio_5, "predio",diretorio_corrigido)
    confinantes_5 = converter_para_polygon_single_2d(confinantes_4)
    escrever_no_gpkg(confinantes_4, "confinantes",diretorio_corrigido)
    dom_pub_3 = converter_para_polygon_single_2d(dom_pub_2)
    escrever_no_gpkg(dom_pub_3, "dominio_publico",diretorio_corrigido)
    area_nao_cadastrada_2 = converter_para_polygon_single_2d(area_nao_cadastrada_1)
    escrever_no_gpkg(area_nao_cadastrada_2, "area_nao_cadastrada",diretorio_corrigido)
    dom_pub_conf_1 = converter_para_polygon_single_2d(dom_pub_conf)
    escrever_no_gpkg(dom_pub_conf_1, "dominio_publico_confinante",diretorio_corrigido)
    adicionais_1 = converter_para_polygon_single_2d(adicionais)
    escrever_no_gpkg(adicionais_1, "adicionais",diretorio_corrigido)

    # 5) Adicionar resultados ao projeto
    for layer in [predio_5, confinantes_5, dom_pub_3, area_nao_cadastrada_2, dom_pub_conf_1]:
        adicionar_ao_grupo(layer, GRUPO_RESULTADOS)

    print("\n=== ✔ PROCESSO CONCLUÍDO COM SUCESSO ===\n")
    remover_grupo("resultados")
    remover_grupo("corrigidos")
    adicionar_gpkg_ao_projeto(diretorio_corrigido, CAMADAS_BASE, GRUPO_CORRIGIDOS)
    
    root = QgsProject.instance().layerTreeRoot()
    grupo = root.findGroup("corrigidos")
    camadas = [child.layer() for child in grupo.children() if hasattr(child, "layer")]
    # Dicionário de cores
    cores = {
        "predio": "0,0,255",              # azul
        "confinantes": "255,105,180",     # rosa
        "dominio_publico": "0,0,0",       # preto
        "area_nao_cadastrada": "0,0,255"  # azul
    }
        # Aplicar simbologia às camadas encontradas
    for lyr in camadas:
        if lyr is None:
            continue

        nome = lyr.name().lower()

        cor = None
        for chave, valor in cores.items():
            if chave in nome:
                cor = valor
                break

        if not cor:
            continue

        simb = QgsFillSymbol.createSimple({
            "color": "0,0,0,0",
            "outline_color": cor,
            "outline_width": "0.8"
    })

        lyr.setRenderer(QgsSingleSymbolRenderer(simb))
        lyr.triggerRepaint()


    msg1=(f"Processo de correção concluído.")
    return msg1

# Executar
# executar_processo_ajuste(diretorio_corrigido)
