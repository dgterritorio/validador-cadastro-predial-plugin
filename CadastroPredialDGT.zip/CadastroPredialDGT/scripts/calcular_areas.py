from qgis.core import QgsProject, QgsWkbTypes

def calcular_areas_mensagem():
    project = QgsProject.instance()

    def listar_areas(layer, titulo_log):
        if not layer:
            return f"- A camada {titulo_log}: não foi encontrada\n"

        if QgsWkbTypes.geometryType(layer.wkbType()) != QgsWkbTypes.PolygonGeometry:
            return f"- A camada {titulo_log}: não é do tipo polígono\n"

        linhas = [f"Camada {titulo_log}:"]
        for f in layer.getFeatures():
            geom = f.geometry()
            if not geom or geom.isEmpty():
                continue

            area = geom.area()
            fid = f.id()
            linhas.append(f"  FID {fid}: area = {area:.3f} m²")

        linhas.append("")
        return "\n".join(linhas)

    root = project.layerTreeRoot()
    msg = []

    grupo_originais = root.findGroup('originais')
    if grupo_originais:
        camada_predio_orig = None
        for child in grupo_originais.children():
            lyr = child.layer()
            if lyr and lyr.name().lower() == 'predio':
                camada_predio_orig = lyr
                break
        msg.append(listar_areas(camada_predio_orig, "originais/predio"))
    else:
        msg.append("Grupo 'originais' não encontrado.\n")

    grupo_sub = root.findGroup('submetidos')
    if grupo_sub:
        nomes_alvo = ["predio", "dominio_publico", "area_nao_cadastrada"]
        camadas = {n: None for n in nomes_alvo}
        for child in grupo_sub.children():
            lyr = child.layer()
            if not lyr:
                continue
            n = lyr.name().lower()
            if n in camadas:
                camadas[n] = lyr
        for n, lyr in camadas.items():
            msg.append(listar_areas(lyr, f"submetidos/{n}"))
    else:
        msg.append("Grupo 'submetidos' não encontrado.\n")

    texto = "\n".join(msg)
    return texto
# Executar
# calcular_areas_mensagem()