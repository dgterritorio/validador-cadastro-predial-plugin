# ==========================================================
# Remover camadas temporárias do projeto QGIS
# ==========================================================
# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY,
    QgsField, QgsFields, QgsWkbTypes, QgsSpatialIndex, QgsVectorFileWriter
)
from qgis.utils import iface
from qgis.core import Qgis, QgsMessageLog
import tempfile, os
from datetime import datetime
from qgis.PyQt.QtWidgets import QMessageBox

def mostrar_mensagem(texto):
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Resultado Vértices inconsistentes ")
    msg_box.setText(texto)
    msg_box.exec_()

# Identificação do nome de cada camada a remover
def remove_camadas():
    
    camadas_remover = ["todos_poligonos","todos_vertices","vertices_sem_duplicados","vertices_analise","vertices_analise_2","Resultado","vertices_unicos","linhas","dados_originais","dados_submetidos","dados_originais1","prd_conf_1_point","prd_conf_2_point","prd_conf_2_polygon","dados_submetidos1","vertices_criticos_originais","vertices_criticos_submetidos","prd_conf_1_line","prd_conf_2_line","prd_conf_1_polygon","prd_conf_3_polygon","confinantes_erros","predio_original_ajustada","dominio_publico_erro","area_nao_cadastrada_erro","auxiliares"]
    projeto = QgsProject.instance()
    for nome in camadas_remover:
        for lyr in projeto.mapLayersByName(nome):
            projeto.removeMapLayer(lyr.id())
# Executar
#remove_camadas()