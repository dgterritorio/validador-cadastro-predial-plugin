# ==========================================================
# Verifica se faltam vértices entre estremas comuns
# ==========================================================
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry,
    QgsPointXY, QgsField, QgsWkbTypes, QgsSpatialIndex,
    QgsFeatureRequest, QgsLayerTreeGroup
)
from qgis.PyQt.QtCore import QVariant
from qgis.utils import iface
from qgis.core import QgsMarkerSymbol
from collections import Counter


# ==========================================================
# Utilitários
# ==========================================================

def mostrar_mensagem(texto):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information)
    msg.setWindowTitle("Faltam vértices em estremas comuns")
    msg.setText(texto)
    msg.exec_()


def obter_camadas_do_grupo(nome_grupo):
    """Obtém todas as camadas dentro de um grupo do projeto."""
    projeto = QgsProject.instance()
    raiz = projeto.layerTreeRoot()

    grupo = raiz.findGroup(nome_grupo)
    if not grupo:
        iface.messageBar().pushWarning("Aviso", f"Grupo '{nome_grupo}' não encontrado.")
        return []

    camadas = []
    for item in grupo.children():
        if hasattr(item, "layer") and item.layer() is not None:
            camadas.append(item.layer())

    return camadas


def adicionar_ao_grupo(layer, nome_grupo):
    """Adiciona camada a um grupo do projeto QGIS."""
    projeto = QgsProject.instance()
    raiz = projeto.layerTreeRoot()

    grupo = raiz.findGroup(nome_grupo)
    if not grupo:
        grupo = raiz.addGroup(nome_grupo)

    projeto.addMapLayer(layer, False)
    grupo.insertLayer(0, layer)

# ==========================================================
# PASSO 1 – PROCESSAR POLÍGONOS E VÉRTICES
# ==========================================================

def processar_poligonos_e_vertices():
    """Cria camadas auxiliares a partir das camadas do grupo 'submetidos'."""

    projeto = QgsProject.instance()

    # Usar apenas poligonos GPKG dentro de "submetidos"
    camadas_poligonos = [
        lyr for lyr in obter_camadas_do_grupo("submetidos")
        if lyr.isValid()
        and lyr.providerType() == "ogr"
        and "gpkg" in lyr.source().lower()
        and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry
    ]

    if not camadas_poligonos:
        iface.messageBar().pushWarning(
            "Aviso", "Nenhuma camada válida encontrada no grupo 'submetidos'."
        )
        return

    crs = camadas_poligonos[0].crs().authid()

    # --------------------------
    # 1) todos_poligonos
    # --------------------------
    todos_poligonos = QgsVectorLayer(f"Polygon?crs={crs}", "todos_poligonos", "memory")
    dp_pol = todos_poligonos.dataProvider()
    dp_pol.addAttributes([QgsField("code", QVariant.Int)])
    todos_poligonos.updateFields()

    code = 1
    features_pol = []

    for camada in camadas_poligonos:
        for feat in camada.getFeatures():
            f = QgsFeature()
            f.setGeometry(feat.geometry())
            f.setAttributes([code])
            features_pol.append(f)
            code += 1

    dp_pol.addFeatures(features_pol)
    todos_poligonos.updateExtents()
    adicionar_ao_grupo(todos_poligonos, "resultados")

    # --------------------------
    # 2) todos_vertices
    # --------------------------
    todos_vertices = QgsVectorLayer(f"Point?crs={crs}", "todos_vertices", "memory")
    dp_vert = todos_vertices.dataProvider()
    dp_vert.addAttributes([
        QgsField("code", QVariant.Int),
        QgsField("x", QVariant.Double),
        QgsField("y", QVariant.Double)
    ])
    todos_vertices.updateFields()

    feats_vertices = []

    for feat in todos_poligonos.getFeatures():
        geom = feat.geometry()
        code_val = feat["code"]

        if geom.isMultipart():
            partes = geom.asMultiPolygon()
        else:
            partes = [geom.asPolygon()]

        for pol in partes:
            for anel in pol:
                # Remover vértice repetido final
                if len(anel) > 1 and anel[0] == anel[-1]:
                    anel = anel[:-1]

                for pt in anel:
                    f = QgsFeature()
                    f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt.x(), pt.y())))
                    f.setAttributes([code_val, pt.x(), pt.y()])
                    feats_vertices.append(f)

    dp_vert.addFeatures(feats_vertices)
    todos_vertices.updateExtents()
    adicionar_ao_grupo(todos_vertices, "resultados")

    # --------------------------
    # 3) vertices_sem_duplicados
    # --------------------------
    sem_dups = QgsVectorLayer(
        f"Point?crs={crs}", "vertices_sem_duplicados", "memory"
    )
    dp_sd = sem_dups.dataProvider()
    dp_sd.addAttributes([
        QgsField("code", QVariant.Int),
        QgsField("x", QVariant.Double),
        QgsField("y", QVariant.Double)
    ])
    sem_dups.updateFields()

    vistos = set()
    feats_sd = []

    for feat in todos_vertices.getFeatures():
        code_val = feat["code"]
        x = round(feat["x"], 8)
        y = round(feat["y"], 8)
        chave = (code_val, x, y)

        if chave in vistos:
            continue
        vistos.add(chave)

        novo = QgsFeature()
        novo.setGeometry(feat.geometry())
        novo.setAttributes([code_val, x, y])
        feats_sd.append(novo)

    dp_sd.addFeatures(feats_sd)
    sem_dups.updateExtents()
    adicionar_ao_grupo(sem_dups, "resultados")

# ==========================================================
# PASSO 2 – vertices_analise
# ==========================================================

def criar_vertices_analise():
    projeto = QgsProject.instance()
    lyr = projeto.mapLayersByName("vertices_sem_duplicados")

    if not lyr:
        iface.messageBar().pushWarning("Erro", "Camada 'vertices_sem_duplicados' não encontrada.")
        return

    lyr = lyr[0]
    crs = lyr.crs().authid()

    contador = Counter()
    coords = []

    for f in lyr.getFeatures():
        x = round(f["x"], 8)
        y = round(f["y"], 8)
        coords.append((x, y))
        contador[(x, y)] += 1

    out = QgsVectorLayer(f"Point?crs={crs}", "vertices_analise", "memory")
    dp = out.dataProvider()
    dp.addAttributes([
        QgsField("x", QVariant.Double),
        QgsField("y", QVariant.Double),
        QgsField("contagem", QVariant.Int)
    ])
    out.updateFields()

    vistos = set()
    feats = []

    for x, y in coords:
        if (x, y) in vistos:
            continue
        vistos.add((x, y))

        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
        f.setAttributes([x, y, contador[(x, y)]])
        feats.append(f)

    dp.addFeatures(feats)
    out.updateExtents()
    adicionar_ao_grupo(out, "resultados")

# ==========================================================
# PASSO 3 – vertices_analise_2
# ==========================================================

def criar_vertices_analise_2_com_buffer():
    proj = QgsProject.instance()
    verts = proj.mapLayersByName("vertices_analise")
    polys = proj.mapLayersByName("todos_poligonos")

    if not verts or not polys:
        iface.messageBar().pushWarning("Erro", "Camadas necessárias não encontradas.")
        return

    verts = verts[0]
    polys = polys[0]
    crs = verts.crs().authid()

    index = QgsSpatialIndex(polys.getFeatures())

    out = QgsVectorLayer(f"Point?crs={crs}", "vertices_analise_2", "memory")
    dp = out.dataProvider()
    dp.addAttributes([
        QgsField("x", QVariant.Double),
        QgsField("y", QVariant.Double),
        QgsField("contagem", QVariant.Int),
        QgsField("nr_V", QVariant.Int)
    ])
    out.updateFields()

    feats = []

    for v in verts.getFeatures():
        x, y, cont = v["x"], v["y"], v["contagem"]
        pt = QgsGeometry.fromPointXY(QgsPointXY(x, y))
        buf = pt.buffer(0.001, 8)

        cand_ids = index.intersects(buf.boundingBox())
        nr = 0

        for pid in cand_ids:
            poly = next(polys.getFeatures(QgsFeatureRequest(pid)), None)
            if poly and buf.intersects(poly.geometry()):
                nr += 1

        f = QgsFeature()
        f.setGeometry(pt)
        f.setAttributes([x, y, cont, nr])
        feats.append(f)

    dp.addFeatures(feats)
    out.updateExtents()
    adicionar_ao_grupo(out, "resultados")

# ==========================================================
# PASSO 4 – Vertices_em_falta
# ==========================================================


def criar_vertices_em_falta():
    proj = QgsProject.instance()
    lyr = proj.mapLayersByName("vertices_analise_2")

    if not lyr:
        iface.messageBar().pushWarning("Erro", "Camada 'vertices_analise_2' não encontrada.")
        return

    lyr = lyr[0]
    crs = lyr.crs().authid()

    out = QgsVectorLayer(f"Point?crs={crs}", "Vertices_em_falta", "memory")
    dp = out.dataProvider()
    dp.addAttributes([
        QgsField("x", QVariant.Double),
        QgsField("y", QVariant.Double),
        QgsField("contagem", QVariant.Int),
        QgsField("nr_V", QVariant.Int),
        QgsField("diff", QVariant.Int)
    ])
    out.updateFields()

    feats = []

    for f in lyr.getFeatures():
        x, y = f["x"], f["y"]
        cont, nr = f["contagem"], f["nr_V"]
        diff = cont - nr

        if diff != 0:
            nf = QgsFeature()
            nf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
            nf.setAttributes([x, y, cont, nr, diff])
            feats.append(nf)

    if not feats:
        
        msg1=(f"0")
        #return 0
        return msg1

    dp.addFeatures(feats)
    out.updateExtents()
    adicionar_ao_grupo(out, "resultados")

    # Simbolização automática — círculo com a cor laranja
    symbol = QgsMarkerSymbol.createSimple({
        "name": "circle",
        "color": "255,128,0",
        "size": "3"
    })
    out.renderer().setSymbol(symbol)
    out.triggerRepaint()
    vertices_em_falta=len(feats)
    return vertices_em_falta   # ← devolve para fora da função


def remover_camadas_auxiliares():
    nomes = [
        "todos_poligonos",
        "todos_vertices",
        "vertices_sem_duplicados",
        "vertices_analise",
        "vertices_analise_2"
    ]

    proj = QgsProject.instance()

    for nome in nomes:
        for lyr in proj.mapLayersByName(nome):
            proj.removeMapLayer(lyr.id())

    iface.messageBar().pushInfo("temporários", "Camadas auxiliares removidas.")
#Executar
#criar_vertices_em_falta()