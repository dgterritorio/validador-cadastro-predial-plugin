# ==========================================================
# Deteta sobreposições nas camadas geopackage existentes no grupo "submetidos"
# ==========================================================
from qgis.core import (
    QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry,
    QgsField, QgsSpatialIndex, QgsWkbTypes, Qgis
)
from qgis.PyQt.QtCore import QVariant
from qgis.utils import iface
from PyQt5.QtWidgets import QMessageBox

# ==========================================================
# Utilitários
# ==========================================================

def mostrar_mensagem(texto):
    """Exibe uma caixa de diálogo com a mensagem."""
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Sobreposiçoes")
    msg_box.setText(texto)
    msg_box.exec_()


def obter_camadas_submetidos():
    """Obtém apenas as camadas do grupo 'submetidos' que são GPKG de polígonos."""
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()

    grupo = root.findGroup("submetidos")
    if not grupo:
        iface.messageBar().pushWarning("Sobreposições", "O grupo 'submetidos' não existe.")
        return []

    camadas = []
    for node in grupo.children():
        if hasattr(node, "layer"):
            lyr = node.layer()
            if (
                lyr
                and lyr.isValid()
                and lyr.providerType() == "ogr"
                and "gpkg" in lyr.source().lower()
                and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry
            ):
                camadas.append(lyr)

    return camadas


def adicionar_resultado_ao_grupo(layer):
    """Adiciona a camada resultante ao grupo 'resultados'."""
    projeto = QgsProject.instance()
    root = projeto.layerTreeRoot()

    grupo_res = root.findGroup("resultados")
    if not grupo_res:
        grupo_res = root.addGroup("resultados")

    QgsProject.instance().addMapLayer(layer, addToLegend=False)
    grupo_res.addLayer(layer)

# ==========================================================
# Detetar as sobreposições entre polígonos
# ==========================================================

def detectar_sobreposicoes():
    camadas = obter_camadas_submetidos()

    if not camadas:
        iface.messageBar().pushInfo("Sobreposições", "Nenhuma camada válida no grupo 'submetidos'.")
        return

    # Preparar lista de geometrias
    feats = [
        (lyr.name(), feat.id(), feat.geometry())
        for lyr in camadas
        for feat in lyr.getFeatures()
        if feat.geometry() and not feat.geometry().isEmpty()
    ]

    if len(feats) < 2:
        iface.messageBar().pushInfo("Sobreposições", "Não existem polígonos suficientes para análise.")
        msg5=(f"0")
        return msg5

    # Criar índice espacial
    index = QgsSpatialIndex()
    for idx, (_, _, geom) in enumerate(feats):
        temp_f = QgsFeature()
        temp_f.setGeometry(geom)
        temp_f.setId(idx)
        index.insertFeature(temp_f)

    # Criar camada de saída
    crs_auth = camadas[0].crs().authid()
    out = QgsVectorLayer(f"MultiPolygon?crs={crs_auth}", "Sobreposicoes", "memory")
    pr = out.dataProvider()
    pr.addAttributes([
        QgsField("layer1", QVariant.String),
        QgsField("fid1", QVariant.Int),
        QgsField("layer2", QVariant.String),
        QgsField("fid2", QVariant.Int),
    ])
    out.updateFields()

    feats_out = []

    # Detetar sobreposições
    for i, (l1, f1, g1) in enumerate(feats):
        for j in index.intersects(g1.boundingBox()):
            if j <= i:
                continue

            l2, f2, g2 = feats[j]
            inter = g1.intersection(g2)

            if not inter or inter.isEmpty():
                continue

            # Garantir que devolve polígonos
            if inter.wkbType() == QgsWkbTypes.GeometryCollection:
                success = inter.convertGeometryCollectionToSubclass(Qgis.GeometryType.Polygon)
                if not success:
                    parts = inter.extractPartsByType(QgsWkbTypes.Polygon)
                    if parts:
                        inter = QgsGeometry.collectGeometry(parts)
                    else:
                        continue

            if inter and not inter.isEmpty() and inter.area() > 0:
                feat = QgsFeature(out.fields())
                feat.setGeometry(inter)
                feat.setAttributes([l1, f1, l2, f2])
                feats_out.append(feat)

    # Adicionar resultados
    if feats_out:
        pr.addFeatures(feats_out)
        out.updateExtents()
        #ADICIONAR AO GRUPO "resultados"
        adicionar_resultado_ao_grupo(out)
        n_sobreposicoes=len(feats_out)
        msg5=(f"{n_sobreposicoes}")
        return msg5
        
    
    else:
        
        msg5=(f"0")
        return msg5
    
# Executar
#detectar_sobreposicoes()
#adicionar_resultado_ao_grupo(out)
