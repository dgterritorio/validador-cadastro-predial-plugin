# ==========================================================
# Verifica se existem vértices duplicados
# Apenas cria ficheiro de erros se existirem duplicados.
# ==========================================================

from qgis.core import (
    QgsProject, QgsGeometry, QgsPointXY, QgsVectorLayer,
    QgsVectorFileWriter, QgsFields, QgsField, QgsFeature, QgsWkbTypes
)
from PyQt5.QtCore import QVariant
from PyQt5.QtWidgets import QMessageBox
import tempfile
import os


# ==========================================================
# Utilitários
# ==========================================================

def get_xy(pt):
    """Extrai as coordenadas de um ponto e arredonda 9 casas decimais."""
    return round(float(pt.x()), 9), round(float(pt.y()), 9)

def mostrar_mensagem(texto):
    msg_box = QMessageBox()
    msg_box.setIcon(QMessageBox.Information)
    msg_box.setWindowTitle("Vértices duplicados")
    msg_box.setText(texto)
    msg_box.exec_()


def extract_polygon_rings_vertices(geom):
    """
    Devolve uma lista de anéis, cada um com uma lista de vértices (x, y),
    removendo o último ponto repetido que fecha o polígono.
    """
    rings = []

    if geom is None or geom.isEmpty():
        return rings

    geom = geom.convertToType(QgsWkbTypes.PolygonGeometry, True)

    if geom.isMultipart():
        polys = geom.asMultiPolygon()
    else:
        polys = [geom.asPolygon()]

    for poly in polys:
        for ring in poly:

            if not ring:
                continue

            coords = [get_xy(pt) for pt in ring]

            # remover ponto de fecho (primeiro == último)
            if len(coords) > 1 and coords[0] == coords[-1]:
                coords = coords[:-1]

            rings.append(coords)

    return rings



def extract_polygon_vertices_clean(geom):
    """
    Extrai vértices de polígonos removendo duplicação do fim do polígono
    (primeiro == último).
    """
    vertices = []

    if geom is None or geom.isEmpty():
        return vertices

    geom = geom.convertToType(QgsWkbTypes.PolygonGeometry, True)

    if geom.isMultipart():
        polys = geom.asMultiPolygon()
    else:
        polys = [geom.asPolygon()]

    for poly in polys:
        for ring in poly:

            if not ring:
                continue

            raw = [get_xy(pt) for pt in ring]

            # remover ponto que fecha o polígono
            if len(raw) > 1 and raw[0] == raw[-1]:
                raw = raw[:-1]

            vertices.extend(raw)

    return vertices



def detectar_vertices_duplicados():

    project = QgsProject.instance()
    root = project.layerTreeRoot()

    grupo_sub = root.findGroup("submetidos")
    grupo_res = root.findGroup("resultados")

    if not grupo_sub or not grupo_res:
        print("❌ É necessário existirem os grupos 'submetidos' e 'resultados' .")
        return

    # Procurar camadas de polígonos
    camadas_poligono = []
    for nodo in grupo_sub.children():
        lyr = nodo.layer()
        if lyr and QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PolygonGeometry:
            camadas_poligono.append(lyr)

    if not camadas_poligono:
        print("❌ Nenhuma camada de polígonos encontrada.")
        return

    print("➡ Camadas analisadas:", [l.name() for l in camadas_poligono])

    # conjunto global de vértices duplicados, mas **apenas** se forem duplicados
    # dentro do mesmo polígono (não entre polígonos diferentes)
    duplicados_globais = set()

    for lyr in camadas_poligono:
        for feat in lyr.getFeatures():

            rings = extract_polygon_rings_vertices(feat.geometry())

            # se quiseres ignorar aneis interiores, usa só rings[0]
            # rings_to_check = [rings[0]] if rings else []
            rings_to_check = rings

            # Detetar por polígono (reinicia para cada feat)
            duplicados_feat = set()

            for ring_vertices in rings_to_check:
                vistos = set()
                for xy in ring_vertices:
                    if xy in vistos:
                        duplicados_feat.add(xy)
                    else:
                        vistos.add(xy)

            # acumular no conjunto global apenas o que é duplicado dentro deste polígono
            duplicados_globais.update(duplicados_feat)

    total = len(duplicados_globais)

    msg1 = f"{total}"

    if total == 0:
        return msg1

    # ==========================
    # Criar ficheiro apenas se existirem duplicados
    # ==========================

    print("➡ A criar ficheiro com erros...")

    tmpdir = tempfile.mkdtemp(prefix="qgis_dup_verts_")
    gpkg_saida = os.path.join(tmpdir, "vertices_duplicados.gpkg")
    nome_layer = "vertices_duplicados"

    crs = camadas_poligono[0].crs()

    fields = QgsFields()
    fields.append(QgsField("id", QVariant.Int))

    mem = QgsVectorLayer(f"Point?crs={crs.authid()}", nome_layer, "memory")
    prov = mem.dataProvider()
    prov.addAttributes(fields)
    mem.updateFields()

    feats = []
    idx = 1
    for x, y in duplicados_globais:
        f = QgsFeature()
        f.setFields(fields)
        f["id"] = idx
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
        feats.append(f)
        idx += 1

    prov.addFeatures(feats)

    # Guardar em GPKG
    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GPKG"
    opts.layerName = nome_layer

    QgsVectorFileWriter.writeAsVectorFormatV2(
        mem, gpkg_saida, QgsProject.instance().transformContext(), opts
    )

    lyr_out = QgsVectorLayer(gpkg_saida, nome_layer, "ogr")
    project.addMapLayer(lyr_out, False)
    node = grupo_res.addLayer(lyr_out)
    node.setCustomProperty("showFeatureCount", True)

    return msg1
# Executar
#detectar_vertices_duplicados()